import { initializeApp } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { defineSecret } from "firebase-functions/params";
import { HttpsError, onCall, type CallableRequest } from "firebase-functions/v2/https";

// `src/shared` is copied from the Next.js app by `npm run sync:shared` (see root package.json).
import { chatTurn as runChatTurn, createConversation } from "./shared/agent";
import { chaosProvider, runEval } from "./shared/eval/harness";
import { DEFAULT_SUITE_ID, TESTCASES, type EvalCase } from "./shared/eval/testcases";
import { createProvider } from "./shared/llm";
import { generateProposal as buildProposal, ProposalError } from "./shared/proposal";
import { FirestoreStore } from "./shared/store/firestore-store";

initializeApp();
const store = new FirestoreStore(getFirestore());
const LLM_API_KEY = defineSecret("LLM_API_KEY"); // firebase functions:secrets:set LLM_API_KEY

function assertAdmin(req: CallableRequest) {
  if (!req.auth) throw new HttpsError("unauthenticated", "Sign in required");
  const allow = (process.env.ADMIN_EMAILS ?? "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
  const email = (req.auth.token.email ?? "").toLowerCase();
  if (req.auth.token.admin !== true && !(req.auth.token.email_verified && allow.includes(email))) {
    throw new HttpsError("permission-denied", "Admin only");
  }
}

/** chatTurn(conversationId, message) → { reply, toolCalls[] }.  Public: prospects are anonymous. */
export const chatTurn = onCall({ secrets: [LLM_API_KEY], cors: true, maxInstances: 20, timeoutSeconds: 60 }, async (req) => {
  const { conversationId, message } = (req.data ?? {}) as { conversationId?: string; message?: string };
  try {
    let id = conversationId;
    let greeting: string | undefined;
    if (!id) {
      id = (await createConversation(store)).conversationId; // first call without an id starts a conversation
      greeting = (await store.getConversation(id))?.messages[0]?.content;
      if (!message) return { conversationId: id, reply: greeting, toolCalls: [] };
    }
    const r = await runChatTurn({ store, llm: createProvider() }, id, message ?? "");
    return { conversationId: id, reply: r.reply, toolCalls: r.toolCalls, stage: r.stage, unknowns: r.unknowns };
  } catch (e) {
    const code = (e as { code?: string }).code;
    if (code === "empty_message" || code === "message_too_long") throw new HttpsError("invalid-argument", code);
    if (code === "conversation_not_found") throw new HttpsError("not-found", code);
    if (code === "turn_limit_reached") throw new HttpsError("resource-exhausted", code);
    throw new HttpsError("internal", "chat_failed");
  }
});

/** runEvalSuite(suiteId) → { report, failures[] }.  Admin only. Runs on an isolated in-memory store. */
export const runEvalSuite = onCall({ secrets: [LLM_API_KEY], cors: true, timeoutSeconds: 300, memory: "512MiB" }, async (req) => {
  assertAdmin(req);
  const { suiteId = DEFAULT_SUITE_ID, chaos = false } = (req.data ?? {}) as { suiteId?: string; chaos?: boolean };
  let suite: EvalCase[] = TESTCASES;
  const saved = await store.getEvalSuite(suiteId);
  if (saved) suite = saved.testcases as EvalCase[];
  else if (suiteId === DEFAULT_SUITE_ID) await store.saveEvalSuite({ id: suiteId, name: "Default 20 scripted conversations", testcases: TESTCASES });
  else throw new HttpsError("not-found", "suite_not_found");
  const base = createProvider();
  const report = await runEval({ suite, suiteId, llm: chaos ? chaosProvider(base) : base });
  await store.saveEvalReport({ id: `${suiteId}-${report.createdAt}`, suiteId, createdAt: report.createdAt, metrics: report.metrics, failures: report.failures });
  return { report, failures: report.failures };
});

/** generateProposal(leadId) → { proposalMarkdown, assumptions[] }.  Admin only. */
export const generateProposal = onCall({ cors: true }, async (req) => {
  assertAdmin(req);
  const { leadId } = (req.data ?? {}) as { leadId?: string };
  if (!leadId) throw new HttpsError("invalid-argument", "leadId required");
  const lead = await store.getLead(leadId);
  if (!lead) throw new HttpsError("not-found", "lead_not_found");
  try {
    return buildProposal(lead);
  } catch (e) {
    if (e instanceof ProposalError) throw new HttpsError("failed-precondition", e.message);
    throw e;
  }
});
