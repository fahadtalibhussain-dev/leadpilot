import { NEEDS, type Need } from "./pricing.config";
import type { ExtractedFields, UnknownField } from "./schemas";

/**
 * Rule-based fact extraction used by the deterministic MockProvider (so the eval suite is
 * reproducible without an API key). Real LLM providers do this themselves through extractLead.
 * Only facts that are NEW or CHANGED versus what is already stored are returned.
 */

const NEED_PATTERNS: Record<Need, RegExp> = {
  ecommerce: /e-?commerce|online (?:store|shop)|shopify|sell (?:products )?online|web ?shop/i,
  mobile_app: /mobile app|\bios\b|\bandroid\b|react native|flutter/i,
  ai_automation: /\bai\b|automat(?:e|ion)|chatbot|\bllm\b|\bagents?\b/i,
  web_app: /web ?app|dashboard|\bportal\b|\bsaas\b|\bcrm\b|internal tool|platform|admin panel/i,
  website: /web ?site|landing page|company site|portfolio site/i,
  seo: /\bseo\b|search engine/i,
};

const MULT: Record<string, number> = { k: 1e3, thousand: 1e3, m: 1e6, million: 1e6 };
const NUM = String.raw`(\d[\d,]*(?:\.\d+)?)\s?(thousand|million|k|m)?\b`;

function toNumber(num: string, suffix?: string): number {
  return Math.round(parseFloat(num.replace(/,/g, "")) * (suffix ? MULT[suffix.toLowerCase()] : 1));
}

export function findBudget(text: string, lastAsked?: UnknownField): number | undefined {
  const patterns = [
    new RegExp(String.raw`budget[^\d$]{0,40}(?:\$|usd\s?)?\s?${NUM}`, "i"),
    new RegExp(String.raw`(?:\$|usd\s?)\s?${NUM}`, "i"),
    new RegExp(String.raw`${NUM}\s?(?:usd|dollars)\b`, "i"),
  ];
  for (const p of patterns) {
    const m = text.match(p);
    if (m) return toNumber(m[1], m[2]);
  }
  if (lastAsked === "budget" && !/(week|month|year|day|people|employee)/i.test(text)) {
    const m = text.match(new RegExp(String.raw`^\D*${NUM}`, "i"));
    if (m) return toNumber(m[1], m[2]);
  }
  return undefined;
}

export function findTimelineWeeks(text: string): number | undefined {
  const t = text.toLowerCase();
  if (/\b(no rush|no deadline|flexible|not in a hurry)\b/.test(t)) return 52;
  let m = t.match(/(\d+(?:\.\d+)?)(?:\s*(?:-|to)\s*(\d+(?:\.\d+)?))?\s*(?:weeks?|wks?)\b/);
  if (m) return Math.round(Math.max(+m[1], +(m[2] ?? 0)));
  m = t.match(/(\d+(?:\.\d+)?)(?:\s*(?:-|to)\s*(\d+(?:\.\d+)?))?\s*months?\b/);
  if (m) return Math.round(Math.max(+m[1], +(m[2] ?? 0)) * 4.345);
  if (/\b(?:an?|one|1)\s+year\b/.test(t)) return 52;
  m = t.match(/(\d+)\s*years?\b/);
  if (m) return +m[1] * 52;
  if (/\bnext month\b/.test(t)) return 4;
  if (/\bnext quarter\b/.test(t)) return 13;
  if (/\b(asap|as soon as possible|right away)\b/.test(t)) return 2;
  return undefined;
}

export function findDecisionMaker(text: string, lastAsked?: UnknownField): boolean | undefined {
  const t = text.toLowerCase();
  const NEG = [
    /\bnot (?:the )?decision[- ]?maker/,
    /\bnot me\b/,
    /\bsomeone else\b.{0,30}(?:decid|approv|sign)/,
    /\b(?:my|our) (?:boss|manager|ceo|cto|director|partners?|board|team lead|client|supervisor)\b.{0,30}(?:decid|decision|approv|sign|call)/,
    /\bneeds? to (?:check|ask|confirm|get approval|run (?:it|this) by)/,
    /\b(?:my|our) \w+ (?:is|are) the decision[- ]?maker/,
    /\bi'?m not (?:the )?(?:one|person)\b/,
  ];
  if (NEG.some((r) => r.test(t))) return false;
  const POS = [
    /\bdecision[- ]?maker\b/,
    /\bi (?:decide|approve)\b/,
    /\bi (?:make|take) the (?:final )?(?:call|decision)/,
    /\b(?:final )?decision is mine\b/,
    /\bit'?s my call\b/,
    /\bi sign off\b/,
  ];
  if (POS.some((r) => r.test(t))) return true;
  if (lastAsked === "decision_maker") {
    if (/^\s*(yes|yeah|yep|yup|correct|sure|me|that'?s me|i am|i do)\b/.test(t)) return true;
    if (/^\s*(no|nope|nah|not really)\b/.test(t)) return false;
  }
  return undefined;
}

const ROLE_RE =
  /\b(co-?founder|founder|ceo|cto|coo|cfo|cmo|owner|director|vice president|vp|head of [a-z]+|(?:product|engineering|marketing|project|operations|general|sales) manager|manager)\b/gi;

function findRole(text: string): string | undefined {
  for (const m of text.matchAll(ROLE_RE)) {
    const before = text.slice(Math.max(0, (m.index ?? 0) - 4), m.index).toLowerCase();
    if (/(my|our) $/.test(before)) continue; // "my manager" is somebody else
    return m[1].toLowerCase();
  }
  return undefined;
}

const NAME_STOP = new Set(["Looking", "Interested", "Not", "Based", "Here", "Ready", "Sorry", "Hoping", "Just", "Also", "Very"]);
const NAME_RE = /(?:[Mm]y name is|[Ii] am|[Ii]'m|[Tt]his is|[Cc]all me)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/;

function findName(text: string): string | undefined {
  const m = text.match(NAME_RE);
  if (!m) return undefined;
  const parts = m[1].split(/\s+/);
  if (NAME_STOP.has(parts[0])) return undefined;
  return parts.join(" ");
}

const COMPANY_STOP = new Set(["I", "We", "The", "My", "Our", "This", "That", "It", "A", "An", "Home", "Work"]);
const COMPANY_RE =
  /(?:\bat|\bfrom|\bwork(?:s|ing)? for|company (?:is|called|named)|(?:founder|ceo|owner|cto|coo|head) of|\b(?:[Ii]|[Ww]e) (?:own|run|founded|started|manage))\s+([A-Z][\w&'-]*(?:\s+[A-Z][\w&'-]*){0,3})/;

function findCompany(text: string): string | undefined {
  const m = text.match(COMPANY_RE);
  if (!m) return undefined;
  const tokens = m[1].split(/\s+/);
  if (COMPANY_STOP.has(tokens[0])) return undefined;
  return tokens.join(" ");
}

const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9-]+(?:\.[A-Z0-9-]+)*\.[A-Z]{2,}/i;
const SKIP_RE = /not sure|don'?t know|no idea|unsure|\bskip\b|prefer not|rather not|haven'?t decided|\btbd\b|can'?t say|not yet decided/i;

export interface Extraction {
  fields: ExtractedFields;
  declined: UnknownField[];
}

export function extractFromText(text: string, existing: ExtractedFields, lastAsked?: UnknownField): Extraction {
  const found: ExtractedFields = {};
  const name = findName(text);
  if (name) found.name = name;
  const email = text.match(EMAIL_RE)?.[0].toLowerCase();
  if (email) found.email = email;
  const company = findCompany(text);
  if (company) found.company = company;
  const role = findRole(text);
  if (role) found.role = role;
  const team = text.match(/team of (\d[\d,]*)|(\d[\d,]*)[- ]?(?:person|people|employees|staff|team members)/i);
  if (team) found.teamSize = parseInt((team[1] ?? team[2]).replace(/,/g, ""), 10);
  const budget = findBudget(text, lastAsked);
  if (budget !== undefined) found.budgetUsd = budget;
  const weeks = findTimelineWeeks(text);
  if (weeks !== undefined) found.timelineWeeks = weeks;
  const dm = findDecisionMaker(text, lastAsked);
  if (dm !== undefined) found.isDecisionMaker = dm;
  const needs = NEEDS.filter((n) => NEED_PATTERNS[n].test(text));
  const newNeeds = needs.filter((n) => !(existing.needs ?? []).includes(n));
  if (newNeeds.length) found.needs = newNeeds;

  // keep only new / changed values
  const fields: ExtractedFields = {};
  for (const [k, v] of Object.entries(found)) {
    const prev = (existing as Record<string, unknown>)[k];
    if (k === "needs" || prev !== v) (fields as Record<string, unknown>)[k] = v;
  }

  const declined: UnknownField[] = [];
  if (lastAsked && SKIP_RE.test(text)) {
    const answered =
      (lastAsked === "budget" && found.budgetUsd !== undefined) ||
      (lastAsked === "timeline" && found.timelineWeeks !== undefined) ||
      (lastAsked === "decision_maker" && found.isDecisionMaker !== undefined) ||
      (lastAsked === "email" && !!found.email) ||
      (lastAsked === "needs" && !!found.needs);
    if (!answered) declined.push(lastAsked);
  }
  return { fields, declined };
}

/** "slot 2", "the second one", "option 3", "last" … → zero-based index */
export function parseSlotChoice(text: string, count: number): number | undefined {
  const t = text.toLowerCase();
  const word: [RegExp, number][] = [
    [/\b(first|1st)\b/, 0],
    [/\b(second|2nd)\b/, 1],
    [/\b(third|3rd)\b/, 2],
    [/\b(fourth|4th)\b/, 3],
    [/\blast\b/, count - 1],
  ];
  const num = t.match(/(?:slot|option|number|#)\s*#?\s*(\d)\b/) ?? t.match(/^\s*(\d)\s*[.!]?\s*$/);
  if (num) {
    const i = parseInt(num[1], 10) - 1;
    return i >= 0 && i < count ? i : undefined;
  }
  for (const [re, i] of word) if (re.test(t)) return i >= 0 && i < count ? i : undefined;
  return undefined;
}
