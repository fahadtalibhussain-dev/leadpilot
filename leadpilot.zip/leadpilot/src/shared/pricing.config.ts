/**
 * SINGLE SOURCE OF TRUTH for everything the agent may say about packages, prices and discounts.
 * The agent can only reference data from this file: tools validate package ids against it and
 * every reply is checked against `allowedAmounts()` / `allowedPercents()` before it is shown.
 *
 * NOTE: the numbers below are PLACEHOLDERS — replace them with Spacenos's real price list.
 */

export const NEEDS = ["ecommerce", "mobile_app", "ai_automation", "web_app", "website", "seo"] as const;
export type Need = (typeof NEEDS)[number];

export const NEED_LABELS: Record<Need, string> = {
  ecommerce: "online store",
  mobile_app: "mobile app",
  ai_automation: "AI automation",
  web_app: "web app",
  website: "website",
  seo: "SEO",
};

export const PACKAGE_IDS = [
  "starter_site",
  "growth_web",
  "ecommerce_pro",
  "mobile_mvp",
  "ai_automation",
  "enterprise_custom",
] as const;
export type PackageId = (typeof PACKAGE_IDS)[number];

export type Billing = "standard" | "annual_prepay";

export interface PackageDef {
  id: PackageId;
  name: string;
  priceUsd: number | null; // null => custom quote, human only
  deliveryWeeks: number | null;
  summary: string;
  features: string[];
  needs: Need[];
  discountEligible: boolean;
}

export const PRICING_CONFIG = {
  version: "2026-10-01",
  currency: "USD",
  discounts: {
    annual_prepay: {
      percent: 10,
      description: "10% off the package price when paid up-front (eligible packages only)",
    },
  },
  qualification: {
    minScore: 60,
    /** If the stated budget is below this share of the package price the lead is not qualified. */
    minBudgetRatio: 0.25,
    enterpriseTeamSize: 500,
    enterpriseMinBudgetUsd: 50000,
  },
  demo: {
    durationMinutes: 30,
    slotsOffered: 4,
    timezone: "Asia/Karachi",
    utcOffsetMinutes: 300,
    hoursLocal: [10, 15],
  },
  packages: {
    starter_site: {
      id: "starter_site",
      name: "Starter Website",
      priceUsd: 1500,
      deliveryWeeks: 3,
      summary: "a fast, SEO-ready marketing website",
      features: ["Up to 5 pages", "Responsive design", "Basic on-page SEO", "Contact form"],
      needs: ["website", "seo"],
      discountEligible: false,
    },
    growth_web: {
      id: "growth_web",
      name: "Growth Web App",
      priceUsd: 6000,
      deliveryWeeks: 8,
      summary: "a custom React + Firebase web app",
      features: ["React + Firebase build", "User authentication", "Admin dashboard", "Up to 3 integrations"],
      needs: ["web_app"],
      discountEligible: true,
    },
    ecommerce_pro: {
      id: "ecommerce_pro",
      name: "E-commerce Pro",
      priceUsd: 9500,
      deliveryWeeks: 10,
      summary: "a complete online store",
      features: [
        "Product catalog and checkout",
        "Payment gateway integration",
        "Order management dashboard",
        "Inventory basics",
      ],
      needs: ["ecommerce"],
      discountEligible: true,
    },
    mobile_mvp: {
      id: "mobile_mvp",
      name: "Mobile App MVP",
      priceUsd: 12000,
      deliveryWeeks: 12,
      summary: "a cross-platform iOS and Android MVP",
      features: [
        "Cross-platform iOS and Android app",
        "User authentication",
        "Push notifications",
        "App store submission support",
      ],
      needs: ["mobile_app"],
      discountEligible: true,
    },
    ai_automation: {
      id: "ai_automation",
      name: "AI Automation Suite",
      priceUsd: 8000,
      deliveryWeeks: 8,
      summary: "a custom AI agent or workflow automation",
      features: ["Workflow audit", "Custom AI agent or automation", "Integration with up to 2 tools", "Monitoring and handover"],
      needs: ["ai_automation"],
      discountEligible: true,
    },
    enterprise_custom: {
      id: "enterprise_custom",
      name: "Enterprise Custom",
      priceUsd: null,
      deliveryWeeks: null,
      summary: "a custom-scoped engagement for larger organisations",
      features: ["Discovery workshop", "Custom architecture", "Dedicated team", "SLA"],
      needs: [],
      discountEligible: false,
    },
  } satisfies Record<PackageId, PackageDef>,
} as const;

export const PACKAGES: Record<PackageId, PackageDef> = PRICING_CONFIG.packages;

export function getPackage(id: PackageId): PackageDef {
  return PACKAGES[id];
}

/** Discount percentage that applies — only ever taken from config. */
export function discountFor(pkg: PackageDef, billing: Billing): number {
  if (billing === "annual_prepay" && pkg.discountEligible && pkg.priceUsd !== null) {
    return PRICING_CONFIG.discounts.annual_prepay.percent;
  }
  return 0;
}

export function finalPrice(pkg: PackageDef, percent: number): number | null {
  if (pkg.priceUsd === null) return null;
  return Math.round(pkg.priceUsd * (100 - percent)) / 100;
}

/** Every dollar amount the agent is allowed to mention (besides what the user said themselves). */
export function allowedAmounts(): Set<number> {
  const out = new Set<number>();
  for (const pkg of Object.values(PACKAGES)) {
    if (pkg.priceUsd === null) continue;
    out.add(pkg.priceUsd);
    const pct = discountFor(pkg, "annual_prepay");
    if (pct > 0) out.add(finalPrice(pkg, pct) as number);
  }
  return out;
}

export function allowedPercents(): Set<number> {
  return new Set<number>([PRICING_CONFIG.discounts.annual_prepay.percent]);
}

const NEED_PRIORITY: Need[] = ["ecommerce", "mobile_app", "ai_automation", "web_app", "website", "seo"];
const NEED_TO_PACKAGE: Record<Need, PackageId> = {
  ecommerce: "ecommerce_pro",
  mobile_app: "mobile_mvp",
  ai_automation: "ai_automation",
  web_app: "growth_web",
  website: "starter_site",
  seo: "starter_site",
};

export interface Recommendation {
  packageId: PackageId;
  primaryNeed?: Need;
  extraNeeds: Need[];
}

export function recommendPackage(f: { needs?: Need[]; teamSize?: number; budgetUsd?: number }): Recommendation {
  const q = PRICING_CONFIG.qualification;
  const needs = f.needs ?? [];
  const primary = NEED_PRIORITY.find((n) => needs.includes(n));
  const extra = needs.filter((n) => n !== primary && NEED_TO_PACKAGE[n] !== (primary ? NEED_TO_PACKAGE[primary] : undefined));
  if ((f.teamSize ?? 0) >= q.enterpriseTeamSize || (f.budgetUsd ?? 0) >= q.enterpriseMinBudgetUsd) {
    return { packageId: "enterprise_custom", primaryNeed: primary, extraNeeds: needs.filter((n) => n !== primary) };
  }
  return { packageId: primary ? NEED_TO_PACKAGE[primary] : "starter_site", primaryNeed: primary, extraNeeds: extra };
}
