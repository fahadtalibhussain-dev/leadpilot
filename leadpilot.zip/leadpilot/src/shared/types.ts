import type { ExtractedFields, Slot, Stage, ToolName, UnknownField } from "./schemas";
import type { Billing, PackageId } from "./pricing.config";

export type ToolResult =
  | { name: ToolName; ok: true; output: unknown }
  | { name: ToolName; ok: false; error: string };

export interface ToolCallRecord {
  name: ToolName;
  args: unknown;
  result: ToolResult;
  at: number;
}

export interface LeadOffer {
  packageId: PackageId;
  billing: Billing;
  priceUsd: number | null;
  discountPercent: number;
  finalPriceUsd: number | null;
  at: number;
}

export interface LeadNote {
  at: number;
  by: string;
  text: string;
}

export interface Lead {
  id: string;
  conversationId: string;
  stage: Stage;
  score: number;
  tier: "hot" | "warm" | "cold";
  extractedFields: ExtractedFields;
  unknowns: UnknownField[];
  riskFlags: string[];
  notes: LeadNote[];
  handoff?: { reason: string; note?: string; ticketId: string; at: number };
  offer?: LeadOffer;
  booking?: { slotId: string; label: string; startsAt: string; at: number };
  createdAt: number;
  updatedAt: number;
}

export interface ConversationState {
  lastAsked?: UnknownField;
  declined: UnknownField[];
  offeredSlots: Slot[];
  offeredPackageId?: PackageId;
  offeredBilling?: Billing;
  urgencyAsked?: boolean;
}

export interface Message {
  role: "user" | "assistant";
  content: string;
  at: number;
  toolCalls?: ToolCallRecord[];
  /** guard classification of a user message, or violations caught on an assistant message */
  guard?: string;
}

export interface Conversation {
  id: string;
  leadId: string;
  messages: Message[];
  state: ConversationState;
  createdAt: number;
  updatedAt: number;
}

export interface EvalSuiteDoc {
  id: string;
  name: string;
  testcases: unknown[];
}

export interface EvalReportDoc {
  id: string;
  suiteId: string;
  createdAt: number;
  metrics: Record<string, unknown>;
  failures: unknown[];
  results?: unknown[];
}
