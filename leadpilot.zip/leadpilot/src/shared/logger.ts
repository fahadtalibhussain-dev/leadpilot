type Level = "info" | "warn" | "error";

let sink: ((line: string) => void) | null = null;
export function setLogSink(fn: ((line: string) => void) | null) {
  sink = fn;
}

const EMAIL_RE = /([A-Z0-9._%+-])[A-Z0-9._%+-]*@([A-Z0-9.-]+\.[A-Z]{2,})/gi;
const PHONE_RE = /\+?\d[\d\s().-]{8,}\d/g;
const SECRET_RE = /\bsk-[A-Za-z0-9_-]{8,}/g;
const SENSITIVE_KEY_RE = /key|secret|token|password|authorization/i;

/** PII + secret redaction applied to every log line. */
export function redact(value: unknown, depth = 0): unknown {
  if (typeof value === "string") {
    const s = value.replace(EMAIL_RE, "$1***@$2").replace(SECRET_RE, "[secret]").replace(PHONE_RE, "[phone]");
    return s.length > 300 ? `${s.slice(0, 300)}…` : s;
  }
  if (value === null || typeof value !== "object") return value;
  if (depth > 4) return "[truncated]";
  if (Array.isArray(value)) return value.slice(0, 20).map((v) => redact(v, depth + 1));
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    out[k] = SENSITIVE_KEY_RE.test(k) ? "[redacted]" : redact(v, depth + 1);
  }
  return out;
}

/** Structured JSON-line logger (picked up automatically by Cloud Logging). */
export function logEvent(level: Level, event: string, data: Record<string, unknown> = {}) {
  if (process.env.LEADPILOT_SILENT === "1") return;
  const line = JSON.stringify({ ts: new Date().toISOString(), level, event, ...(redact(data) as object) });
  if (sink) sink(line);
  else if (level === "error") console.error(line);
  else console.log(line);
}
