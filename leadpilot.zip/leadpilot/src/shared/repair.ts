import { ModelOutputSchema, TOOL_NAMES, ToolCallSchema, type ModelOutput, type ToolCall } from "./schemas";

export type ParseResult =
  | { ok: true; value: ModelOutput; repaired: boolean }
  | { ok: false; error: string };

/** Pull the first balanced {...} object out of a string (string/escape aware). */
function extractObject(text: string): string | null {
  const start = text.indexOf("{");
  if (start < 0) return null;
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < text.length; i++) {
    const c = text[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === "\\") esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === "{") depth++;
    else if (c === "}" && --depth === 0) return text.slice(start, i + 1);
  }
  return null;
}

/** Cheap, deterministic JSON repair: fences, prose around the object, smart quotes, trailing commas. */
export function repairJsonText(raw: string): string {
  let t = raw.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  const obj = extractObject(t);
  if (obj) t = obj;
  t = t.replace(/[“”]/g, '"').replace(/[‘’]/g, "'");
  t = t.replace(/,(\s*[}\]])/g, "$1");
  return t;
}

function tryParse(s: string): unknown {
  try {
    return JSON.parse(s);
  } catch {
    return undefined;
  }
}

/** Accept common model slips ("arguments" instead of "args", "tool" instead of "name"). */
export function coerceToolCall(x: unknown): unknown {
  if (!x || typeof x !== "object") return x;
  const o = { ...(x as Record<string, unknown>) };
  if (o.name === undefined) o.name = o.tool ?? o.tool_name ?? o.function;
  if (o.args === undefined) o.args = o.arguments ?? o.input ?? o.parameters ?? {};
  if (typeof o.args === "string") o.args = tryParse(o.args) ?? {};
  return { name: o.name, args: o.args };
}

export function parseModelOutput(raw: string): ParseResult {
  let repaired = false;
  let obj = tryParse(raw.trim());
  if (obj === undefined) {
    repaired = true;
    obj = tryParse(repairJsonText(raw));
  }
  if (obj === undefined || obj === null || typeof obj !== "object" || Array.isArray(obj)) {
    return { ok: false, error: "Response was not a valid JSON object. Reply with ONLY a JSON object: {reply, toolCalls, asked?}." };
  }
  const o = obj as Record<string, unknown>;
  if (o.toolCalls === undefined && Array.isArray(o.tool_calls)) {
    o.toolCalls = o.tool_calls;
    repaired = true;
  }
  const r = ModelOutputSchema.safeParse(o);
  if (!r.success) {
    const msg = r.error.issues.map((i) => `${i.path.join(".") || "(root)"}: ${i.message}`).join("; ");
    return { ok: false, error: `JSON did not match the schema — ${msg}` };
  }
  return { ok: true, value: r.data, repaired };
}

export interface ParsedCalls {
  calls: ToolCall[];
  invalid: { name?: string; error: string; ungroundedPackage: boolean }[];
}

/** Validate each tool call independently so one bad call doesn't discard the others. */
export function parseToolCalls(raw: unknown[]): ParsedCalls {
  const calls: ToolCall[] = [];
  const invalid: ParsedCalls["invalid"] = [];
  for (const item of raw) {
    const c = coerceToolCall(item);
    const r = ToolCallSchema.safeParse(c);
    if (r.success) {
      calls.push(r.data);
      continue;
    }
    const name = (c as { name?: unknown } | null)?.name;
    const known = typeof name === "string" && (TOOL_NAMES as readonly string[]).includes(name);
    const ungroundedPackage = r.error.issues.some((i) => i.path.includes("packageId"));
    invalid.push({
      name: typeof name === "string" ? name : undefined,
      error: known
        ? r.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ")
        : "unknown tool — only extractLead, scoreLead, suggestOffer, bookSlot, handoffToHuman exist",
      ungroundedPackage,
    });
  }
  return { calls, invalid };
}
