import { checkReply, classifyInput, type GuardKind } from "./guard";
import { QUESTIONS, addFlag, computeUnknowns, nextUnknown } from "./leadLogic";
import type { LlmInput, LlmProvider } from "./llm/types";
import { logEvent } from "./logger";
import { PRICING_CONFIG } from "./pricing.config";
import { parseModelOutput, parseToolCalls } from "./repair";
import type { ExtractedFields, ModelOutput, Stage, ToolName, UnknownField } from "./schemas";
import type { Store } from "./store/store";
import { executeTool, type ToolContext } from "./tools";
import type { Conversation, ConversationState, Lead, ToolCallRecord } from "./types";

export const MAX_ROUNDS = 4;
export const MAX_MESSAGE_CHARS = 2000;
export const MAX_USER_TURNS = 80;

export const GREETING =
  "Hi, I'm LeadPilot, Spacenos's virtual sales assistant. I'll ask a few quick questions to find the right package and book a demo. " +
  QUESTIONS.needs;

const FALLBACK_REPLY = "Sorry — I didn't quite get that. Could you rephrase it for me?";

export class ChatError extends Error {
  constructor(public code: "empty_message" | "message_too_long" | "conversation_not_found" | "turn_limit_reached", message?: string) {
    super(message ?? code);
  }
}

export interface ChatDeps {
  store: Store;
  llm: LlmProvider;
  now?: () => Date;
}

export interface TurnTrace {
  guard: GuardKind;
  violations: string[];
  repairs: number;
  invalidToolCalls: number;
  rounds: number;
  toolNames: ToolName[];
  llm: string;
}

export interface ChatTurnResult {
  reply: string;
  toolCalls: ToolCallRecord[];
  stage: Stage;
  score: number;
  unknowns: UnknownField[];
  extractedFields: ExtractedFields;
  riskFlags: string[];
  trace: TurnTrace;
}

export async function createConversation(store: Store, now = new Date()): Promise<{ conversationId: string; leadId: string }> {
  const leadId = store.newId();
  const conversationId = store.newId();
  const t = now.getTime();
  const lead: Lead = {
    id: leadId,
    conversationId,
    stage: "new",
    score: 0,
    tier: "cold",
    extractedFields: {},
    unknowns: computeUnknowns({}),
    riskFlags: [],
    notes: [],
    createdAt: t,
    updatedAt: t,
  };
  const conv: Conversation = {
    id: conversationId,
    leadId,
    messages: [{ role: "assistant", content: GREETING, at: t }],
    state: { declined: [], offeredSlots: [], lastAsked: "needs" },
    createdAt: t,
    updatedAt: t,
  };
  await store.saveLead(lead);
  await store.saveConversation(conv);
  logEvent("info", "conversation_created", { conversationId, leadId });
  return { conversationId, leadId };
}

function normalizeMessage(raw: unknown): string {
  const m = typeof raw === "string" ? raw.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim() : "";
  if (!m) throw new ChatError("empty_message");
  if (m.length > MAX_MESSAGE_CHARS) throw new ChatError("message_too_long");
  return m;
}

function refusalReply(kind: "injection" | "leak", lead: Lead, state: ConversationState): string {
  const base =
    kind === "leak"
      ? "I can't share internal instructions, keys or configuration."
      : "I can't change pricing, access or settings — I can only work from our published packages.";
  const q = nextUnknown(lead.extractedFields, state.declined);
  return q
    ? `${base} I'm happy to keep helping with your project, though. ${QUESTIONS[q]}`
    : `${base} I'm happy to keep helping with your project — is there anything else about the proposal or demo you'd like to know?`;
}

function groundedFallback(lead: Lead, state: ConversationState): string {
  const base = "I can only quote our published packages and pricing.";
  const q = nextUnknown(lead.extractedFields, state.declined);
  return q ? `${base} ${QUESTIONS[q]}` : `${base} Our team will confirm the details with you on the demo call.`;
}

/** Urgency policy: the reply must contain exactly one question. */
function enforceSingleQuestion(reply: string): string {
  const count = (reply.match(/\?/g) ?? []).length;
  if (count <= 1) return reply;
  const idx = reply.indexOf("?");
  const start = Math.max(reply.lastIndexOf(". ", idx), reply.lastIndexOf("! ", idx));
  return reply.slice(start < 0 ? 0 : start + 2, idx + 1);
}

type ModelCall = { out: ModelOutput; repairs: number; final?: boolean };

const LLM_DOWN: ModelOutput = {
  reply: "I'm having trouble right now, so I've asked a teammate to follow up with you directly.",
  toolCalls: [{ name: "handoffToHuman", args: { reason: "other", note: "LLM unavailable or unrecoverable output" } }],
};

/** Call the provider; auto-repair or re-ask up to 2 times when the JSON is invalid. */
async function callModel(deps: ChatDeps, input: Omit<LlmInput, "repairHint">): Promise<ModelCall> {
  let hint: string | undefined;
  let repairs = 0;
  for (let attempt = 0; attempt < 3; attempt++) {
    let raw: string;
    try {
      raw = await deps.llm.complete({ ...input, repairHint: hint });
    } catch (e) {
      logEvent("error", "llm_error", { message: (e as Error).message });
      return { out: LLM_DOWN, repairs, final: true };
    }
    const parsed = parseModelOutput(raw);
    if (parsed.ok) {
      if (parsed.repaired) {
        repairs++;
        logEvent("info", "model_output_repaired", { attempt });
      }
      return { out: parsed.value, repairs };
    }
    repairs++;
    hint = parsed.error;
    logEvent("warn", "model_output_invalid", { attempt, error: parsed.error });
  }
  logEvent("error", "model_output_unrecoverable", {});
  return { out: LLM_DOWN, repairs, final: true };
}

export async function chatTurn(deps: ChatDeps, conversationId: string, rawMessage: string): Promise<ChatTurnResult> {
  const now = (deps.now ?? (() => new Date()))();
  const message = normalizeMessage(rawMessage);
  const conv = await deps.store.getConversation(conversationId);
  if (!conv) throw new ChatError("conversation_not_found");
  const lead = await deps.store.getLead(conv.leadId);
  if (!lead) throw new ChatError("conversation_not_found");
  if (conv.messages.filter((m) => m.role === "user").length >= MAX_USER_TURNS) throw new ChatError("turn_limit_reached");

  const guard = classifyInput(message);
  for (const f of guard.flags) addFlag(lead, f);
  const history = conv.messages.slice(-12).map((m) => ({ role: m.role, content: m.content }));
  conv.messages.push({ role: "user", content: message, at: now.getTime(), guard: guard.kind === "ok" ? undefined : guard.kind });
  logEvent("info", "chat_turn_start", { conversationId, leadId: lead.id, guard: guard.kind, flags: guard.flags, chars: message.length });

  const records: ToolCallRecord[] = [];
  const trace: TurnTrace = { guard: guard.kind, violations: [], repairs: 0, invalidToolCalls: 0, rounds: 0, toolNames: [], llm: deps.llm.name };
  let reply = "";
  let asked: UnknownField | undefined;

  if (guard.kind === "injection" || guard.kind === "leak") {
    // Never reaches the model: deterministic refusal, then back to the funnel.
    reply = refusalReply(guard.kind, lead, conv.state);
    asked = nextUnknown(lead.extractedFields, conv.state.declined);
    logEvent("warn", "guard_blocked", { leadId: lead.id, kind: guard.kind });
  } else {
    const mode: LlmInput["mode"] = guard.kind === "urgency" ? "extract_only" : "normal";
    if (guard.kind === "urgency") conv.state.urgencyAsked = true;
    const ctx: ToolContext = {
      lead,
      state: conv.state,
      store: deps.store,
      now,
      allowedTools: mode === "extract_only" ? ["extractLead"] : undefined,
    };

    for (let round = 0; round < MAX_ROUNDS; round++) {
      trace.rounds++;
      const { out, repairs, final } = await callModel(deps, {
        round,
        mode,
        history,
        userMessage: message,
        lead: structuredClone(lead),
        state: structuredClone(conv.state),
        toolResults: records,
        now,
      });
      trace.repairs += repairs;
      const { calls, invalid } = parseToolCalls(out.toolCalls);
      for (const bad of invalid) {
        trace.invalidToolCalls++;
        if (bad.ungroundedPackage) trace.violations.push("ungrounded_package");
        logEvent("warn", "invalid_tool_call", { tool: bad.name, error: bad.error });
      }

      const lastRound = round === MAX_ROUNDS - 1 || records.length >= 10;
      if (calls.length === 0 || lastRound || final) {
        if (final || !lastRound) {
          // execute any trailing calls (e.g. handoff on LLM failure) before finishing
          for (const call of calls.slice(0, 5)) {
            const result = await executeTool(call, ctx);
            records.push({ name: call.name, args: call.args, result, at: Date.now() });
          }
        }
        reply = out.reply;
        asked = out.asked;
        break;
      }
      for (const call of calls.slice(0, 5)) {
        const result = await executeTool(call, ctx);
        records.push({ name: call.name, args: call.args, result, at: Date.now() });
      }
    }
    trace.toolNames = records.map((r) => r.name);

    if (guard.kind === "urgency") reply = enforceSingleQuestion(reply);

    // Output-side grounding + leak check on the RAW model reply (this is what the eval counts).
    const userAmounts = [...message.matchAll(/(\d[\d,]*(?:\.\d+)?)\s?(k|K)?/g)].map((m) =>
      Math.round(parseFloat(m[1].replace(/,/g, "")) * (m[2] ? 1000 : 1)),
    );
    if (lead.extractedFields.budgetUsd !== undefined) userAmounts.push(lead.extractedFields.budgetUsd);
    const violations = checkReply(reply, { userAmounts });
    if (violations.length) {
      trace.violations.push(...violations);
      logEvent("warn", "reply_blocked", { leadId: lead.id, violations });
      reply = groundedFallback(lead, conv.state);
      asked = nextUnknown(lead.extractedFields, conv.state.declined);
    }
  }
  trace.toolNames = records.map((r) => r.name);

  if (!reply.trim()) reply = FALLBACK_REPLY;
  conv.state.lastAsked = asked ?? (reply.includes("?") ? nextUnknown(lead.extractedFields, conv.state.declined) : undefined);
  lead.unknowns = computeUnknowns(lead.extractedFields);
  lead.updatedAt = conv.updatedAt = now.getTime();
  conv.messages.push({
    role: "assistant",
    content: reply,
    at: now.getTime(),
    toolCalls: records.length ? records : undefined,
    guard: trace.violations.length ? trace.violations.join(",") : undefined,
  });

  await deps.store.saveLead(lead);
  await deps.store.saveConversation(conv);
  logEvent("info", "chat_turn_end", {
    conversationId,
    leadId: lead.id,
    stage: lead.stage,
    score: lead.score,
    tools: trace.toolNames,
    violations: trace.violations,
    repairs: trace.repairs,
    rounds: trace.rounds,
  });

  return {
    reply,
    toolCalls: records,
    stage: lead.stage,
    score: lead.score,
    unknowns: lead.unknowns,
    extractedFields: lead.extractedFields,
    riskFlags: lead.riskFlags,
    trace,
  };
}

export const DEMO_SLOT_COUNT = PRICING_CONFIG.demo.slotsOffered;
