import type { Conversation, EvalReportDoc, EvalSuiteDoc, Lead } from "../types";

/** Persistence boundary. MemoryStore (tests/demo) and FirestoreStore (production) implement it. */
export interface Store {
  newId(): string;
  getConversation(id: string): Promise<Conversation | null>;
  saveConversation(c: Conversation): Promise<void>;
  getLead(id: string): Promise<Lead | null>;
  saveLead(l: Lead): Promise<void>;
  listLeads(limit?: number): Promise<Lead[]>;
  /** Atomically claim a demo slot. Returns false if somebody else already holds it. */
  claimSlot(slotId: string, leadId: string): Promise<boolean>;
  takenSlots(): Promise<Set<string>>;
  getEvalSuite(id: string): Promise<EvalSuiteDoc | null>;
  saveEvalSuite(s: EvalSuiteDoc): Promise<void>;
  saveEvalReport(r: EvalReportDoc): Promise<void>;
  listEvalReports(limit?: number): Promise<EvalReportDoc[]>;
}
