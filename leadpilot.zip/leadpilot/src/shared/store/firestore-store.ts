import type { Firestore } from "firebase-admin/firestore";
import type { Conversation, EvalReportDoc, EvalSuiteDoc, Lead } from "../types";
import type { Store } from "./store";

/**
 * Firestore layout:
 *   leads/{id}         → { stage, score, extractedFields, riskFlags[], ... }
 *   conversations/{id} → { messages[], state, leadId }
 *   eval_suites/{id}   → { testcases[] }
 *   eval_reports/{id}  → { metrics, failures }
 *   bookings/{slotId}  → { leadId }   (created atomically => no double booking)
 */
export class FirestoreStore implements Store {
  constructor(private db: Firestore) {
    try {
      db.settings({ ignoreUndefinedProperties: true });
    } catch {
      /* settings already applied */
    }
  }

  newId() {
    return this.db.collection("leads").doc().id;
  }

  async getConversation(id: string) {
    const s = await this.db.collection("conversations").doc(id).get();
    return s.exists ? (s.data() as Conversation) : null;
  }
  async saveConversation(c: Conversation) {
    await this.db.collection("conversations").doc(c.id).set(c);
  }
  async getLead(id: string) {
    const s = await this.db.collection("leads").doc(id).get();
    return s.exists ? (s.data() as Lead) : null;
  }
  async saveLead(l: Lead) {
    await this.db.collection("leads").doc(l.id).set(l);
  }
  async listLeads(limit = 100) {
    const snap = await this.db.collection("leads").orderBy("updatedAt", "desc").limit(limit).get();
    return snap.docs.map((d) => d.data() as Lead);
  }
  async claimSlot(slotId: string, leadId: string) {
    try {
      await this.db.collection("bookings").doc(slotId).create({ leadId, at: Date.now() });
      return true;
    } catch (e) {
      const err = e as { code?: number | string; message?: string };
      if (err.code === 6 || err.code === "already-exists" || /ALREADY_EXISTS/.test(String(err.message))) return false;
      throw e;
    }
  }
  async takenSlots() {
    const snap = await this.db.collection("bookings").get();
    return new Set(snap.docs.map((d) => d.id));
  }
  async getEvalSuite(id: string) {
    const s = await this.db.collection("eval_suites").doc(id).get();
    return s.exists ? ({ id, ...(s.data() as object) } as EvalSuiteDoc) : null;
  }
  async saveEvalSuite(s: EvalSuiteDoc) {
    await this.db.collection("eval_suites").doc(s.id).set(s);
  }
  async saveEvalReport(r: EvalReportDoc) {
    await this.db.collection("eval_reports").doc(r.id).set(r);
  }
  async listEvalReports(limit = 20) {
    const snap = await this.db.collection("eval_reports").orderBy("createdAt", "desc").limit(limit).get();
    return snap.docs.map((d) => d.data() as EvalReportDoc);
  }
}
