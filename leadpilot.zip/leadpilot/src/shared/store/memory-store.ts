import { randomUUID } from "crypto";
import type { Conversation, EvalReportDoc, EvalSuiteDoc, Lead } from "../types";
import type { Store } from "./store";

const clone = <T>(v: T): T => structuredClone(v);

export class MemoryStore implements Store {
  private conversations = new Map<string, Conversation>();
  private leads = new Map<string, Lead>();
  private slots = new Map<string, string>();
  private suites = new Map<string, EvalSuiteDoc>();
  private reports = new Map<string, EvalReportDoc>();

  newId() {
    return randomUUID();
  }
  async getConversation(id: string) {
    const c = this.conversations.get(id);
    return c ? clone(c) : null;
  }
  async saveConversation(c: Conversation) {
    this.conversations.set(c.id, clone(c));
  }
  async getLead(id: string) {
    const l = this.leads.get(id);
    return l ? clone(l) : null;
  }
  async saveLead(l: Lead) {
    this.leads.set(l.id, clone(l));
  }
  async listLeads(limit = 100) {
    return [...this.leads.values()]
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .slice(0, limit)
      .map(clone);
  }
  async claimSlot(slotId: string, leadId: string) {
    if (this.slots.has(slotId)) return false;
    this.slots.set(slotId, leadId);
    return true;
  }
  async takenSlots() {
    return new Set(this.slots.keys());
  }
  async getEvalSuite(id: string) {
    const s = this.suites.get(id);
    return s ? clone(s) : null;
  }
  async saveEvalSuite(s: EvalSuiteDoc) {
    this.suites.set(s.id, clone(s));
  }
  async saveEvalReport(r: EvalReportDoc) {
    this.reports.set(r.id, clone(r));
  }
  async listEvalReports(limit = 20) {
    return [...this.reports.values()]
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, limit)
      .map(clone);
  }
}
