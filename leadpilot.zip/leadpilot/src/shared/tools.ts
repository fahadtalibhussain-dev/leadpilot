import type { z } from "zod";
import { logEvent } from "./logger";
import {
  addFlag,
  computeUnknowns,
  fieldKnown,
  isFreeEmail,
  scoreFields,
  syncComputedFlags,
} from "./leadLogic";
import { PACKAGES, PRICING_CONFIG, discountFor, finalPrice, recommendPackage, type Need } from "./pricing.config";
import {
  BookSlotOutputSchema,
  ExtractLeadOutputSchema,
  HandoffOutputSchema,
  ScoreLeadOutputSchema,
  SuggestOfferOutputSchema,
  type Stage,
  type ToolCall,
  type ToolName,
} from "./schemas";
import { availableSlots } from "./slots";
import type { Store } from "./store/store";
import type { ConversationState, Lead, ToolResult } from "./types";

export interface ToolContext {
  lead: Lead;
  state: ConversationState;
  store: Store;
  now: Date;
  /** When set, any other tool is rejected (used for the urgency policy). */
  allowedTools?: ToolName[];
}

const ok = <T>(name: ToolName, schema: z.ZodType<T>, output: T): ToolResult => {
  const parsed = schema.safeParse(output);
  if (!parsed.success) return { name, ok: false, error: "invalid_tool_output" };
  return { name, ok: true, output: parsed.data };
};
const fail = (name: ToolName, error: string): ToolResult => ({ name, ok: false, error });

function setStage(ctx: ToolContext, stage: Stage, why: string) {
  if (ctx.lead.stage === stage) return;
  logEvent("info", "stage_change", { leadId: ctx.lead.id, from: ctx.lead.stage, to: stage, why });
  ctx.lead.stage = stage;
}

/**
 * The only way the agent can change anything. Every call is validated (input schema upstream,
 * output schema here), gated by pipeline policy, and logged.
 */
export async function executeTool(call: ToolCall, ctx: ToolContext): Promise<ToolResult> {
  const started = Date.now();
  let result: ToolResult;
  try {
    if (ctx.allowedTools && !ctx.allowedTools.includes(call.name)) {
      result = fail(call.name, "blocked_by_policy");
    } else {
      switch (call.name) {
        case "extractLead":
          result = extractLead(call, ctx);
          break;
        case "scoreLead":
          result = scoreLead(ctx);
          break;
        case "suggestOffer":
          result = await suggestOffer(call, ctx);
          break;
        case "bookSlot":
          result = await bookSlot(call, ctx);
          break;
        case "handoffToHuman":
          result = handoff(call, ctx);
          break;
      }
    }
  } catch (e) {
    logEvent("error", "tool_exception", { tool: call.name, message: (e as Error).message });
    result = fail(call.name, "internal_error");
  }
  logEvent(result.ok ? "info" : "warn", "tool_call", {
    leadId: ctx.lead.id,
    tool: call.name,
    ok: result.ok,
    error: result.ok ? undefined : result.error,
    ms: Date.now() - started,
  });
  return result;
}

function extractLead(call: Extract<ToolCall, { name: "extractLead" }>, ctx: ToolContext): ToolResult {
  const { fields, declined } = call.args;
  const f = ctx.lead.extractedFields as Record<string, unknown>;
  for (const [k, v] of Object.entries(fields)) {
    if (v === undefined) continue;
    if (k === "needs") f.needs = [...new Set([...((f.needs as Need[] | undefined) ?? []), ...(v as Need[])])];
    else f[k] = v;
  }
  for (const d of declined ?? []) {
    if (!fieldKnown(ctx.lead.extractedFields, d) && !ctx.state.declined.includes(d)) ctx.state.declined.push(d);
  }
  if (isFreeEmail(ctx.lead.extractedFields.email)) addFlag(ctx.lead, "free_email_domain");
  ctx.lead.unknowns = computeUnknowns(ctx.lead.extractedFields);
  return ok("extractLead", ExtractLeadOutputSchema, {
    extracted: ctx.lead.extractedFields,
    unknowns: ctx.lead.unknowns,
    declined: ctx.state.declined,
  });
}

function scoreLead(ctx: ToolContext): ToolResult {
  const d = scoreFields(ctx.lead.extractedFields);
  ctx.lead.score = d.score;
  ctx.lead.tier = d.tier;
  syncComputedFlags(ctx.lead, d.computedFlags);
  ctx.lead.unknowns = computeUnknowns(ctx.lead.extractedFields);
  if (d.qualified && ctx.lead.stage === "new") setStage(ctx, "qualified", `score ${d.score}`);
  return ok("scoreLead", ScoreLeadOutputSchema, {
    score: d.score,
    tier: d.tier,
    qualified: d.qualified,
    reasons: d.reasons,
    unknowns: ctx.lead.unknowns,
    riskFlags: ctx.lead.riskFlags,
    recommendedPackageId: d.packageId,
  });
}

async function suggestOffer(call: Extract<ToolCall, { name: "suggestOffer" }>, ctx: ToolContext): Promise<ToolResult> {
  const { lead, state } = ctx;
  if (lead.stage === "booked" || lead.stage === "won") return fail("suggestOffer", "already_booked");
  if (lead.stage === "lost") return fail("suggestOffer", "lead_closed");
  if (lead.stage !== "qualified" && lead.stage !== "proposal_sent") return fail("suggestOffer", "not_qualified");

  const pkg = PACKAGES[call.args.packageId]; // id already validated against config by the schema
  let billing = call.args.billing;
  const pct = discountFor(pkg, billing);
  if (billing === "annual_prepay" && pct === 0) billing = "standard";
  const annualPct = discountFor(pkg, "annual_prepay");
  const budget = lead.extractedFields.budgetUsd;
  const rec = recommendPackage(lead.extractedFields);

  const requiresHuman = pkg.priceUsd === null;
  const slots = requiresHuman ? [] : await availableSlots(ctx.now, ctx.store);
  const final = finalPrice(pkg, pct);

  if (!requiresHuman) {
    setStage(ctx, "proposal_sent", `offer ${pkg.id}`);
    state.offeredSlots = slots;
    state.offeredPackageId = pkg.id;
    state.offeredBilling = billing;
    lead.offer = { packageId: pkg.id, billing, priceUsd: pkg.priceUsd, discountPercent: pct, finalPriceUsd: final, at: ctx.now.getTime() };
  }

  return ok("suggestOffer", SuggestOfferOutputSchema, {
    package: {
      id: pkg.id,
      name: pkg.name,
      priceUsd: pkg.priceUsd,
      deliveryWeeks: pkg.deliveryWeeks,
      summary: pkg.summary,
      features: pkg.features,
    },
    billing,
    discountPercent: pct,
    finalPriceUsd: final,
    annualPrepayPriceUsd: annualPct > 0 ? finalPrice(pkg, annualPct) : null,
    requiresHuman,
    budgetGapUsd: pkg.priceUsd !== null && budget !== undefined && budget < pkg.priceUsd ? pkg.priceUsd - budget : null,
    extraNeeds: pkg.id === rec.packageId ? rec.extraNeeds : [],
    slots,
  });
}

async function bookSlot(call: Extract<ToolCall, { name: "bookSlot" }>, ctx: ToolContext): Promise<ToolResult> {
  const { lead, state } = ctx;
  if (lead.stage === "booked" || lead.stage === "won") return fail("bookSlot", "already_booked");
  if (lead.stage !== "proposal_sent") return fail("bookSlot", "offer_required_first");
  const slot = state.offeredSlots.find((s) => s.id === call.args.slotId);
  if (!slot) return fail("bookSlot", "slot_not_offered");
  const claimed = await ctx.store.claimSlot(slot.id, lead.id);
  if (!claimed) {
    state.offeredSlots = await availableSlots(ctx.now, ctx.store);
    return fail("bookSlot", "slot_taken");
  }
  lead.booking = { slotId: slot.id, label: slot.label, startsAt: slot.startsAt, at: ctx.now.getTime() };
  setStage(ctx, "booked", `slot ${slot.id}`);
  state.offeredSlots = [];
  return ok("bookSlot", BookSlotOutputSchema, { booked: true, slot });
}

function handoff(call: Extract<ToolCall, { name: "handoffToHuman" }>, ctx: ToolContext): ToolResult {
  const { lead } = ctx;
  if (!lead.handoff) {
    lead.handoff = {
      reason: call.args.reason,
      note: call.args.note,
      ticketId: `HT-${lead.id.replace(/[^a-z0-9]/gi, "").slice(0, 6).toUpperCase()}`,
      at: ctx.now.getTime(),
    };
    logEvent("info", "handoff", { leadId: lead.id, reason: call.args.reason });
  }
  return ok("handoffToHuman", HandoffOutputSchema, {
    handoff: true,
    ticketId: lead.handoff.ticketId,
    reason: call.args.reason,
  });
}

export const TOOL_DESCRIPTIONS = `
extractLead   args: { fields: { name?, email?, company?, role?, teamSize?, budgetUsd?, timelineWeeks?, needs?[ecommerce|mobile_app|ai_automation|web_app|website|seo], isDecisionMaker? }, declined?: [needs|budget|timeline|decision_maker|email|name|company] }
              Store ONLY facts the prospect stated. Never guess. "declined" = fields they refused/were unsure about.
scoreLead     args: {}   Scores the lead 0-100 and may move it to "qualified".
suggestOffer  args: { packageId: ${Object.keys(PACKAGES).join("|")}, billing?: standard|annual_prepay }
              Only works for qualified leads. Prices/discounts come from the config, never from you.
bookSlot      args: { slotId }   Only slot ids returned by suggestOffer are valid; requires an offer first.
handoffToHuman args: { reason: low_fit|enterprise_quote|user_request|safety|other, note? }
`.trim();

export const DEMO_MINUTES = PRICING_CONFIG.demo.durationMinutes;
