import { z } from "zod";
import { NEEDS, PACKAGE_IDS } from "./pricing.config";

export const STAGES = ["new", "qualified", "proposal_sent", "booked", "won", "lost"] as const;
export type Stage = (typeof STAGES)[number];
export const StageSchema = z.enum(STAGES);

export const NeedSchema = z.enum(NEEDS);

export const UNKNOWN_FIELDS = ["needs", "budget", "timeline", "decision_maker", "email", "name", "company"] as const;
export type UnknownField = (typeof UNKNOWN_FIELDS)[number];
export const UnknownFieldSchema = z.enum(UNKNOWN_FIELDS);
/** Must be known (or explicitly declined by the prospect) before an offer is made. */
export const REQUIRED_FIELDS: UnknownField[] = ["needs", "budget", "timeline", "decision_maker", "email"];

/** `.strict()` => any invented key (e.g. "discount") fails validation instead of being stored. */
export const ExtractedFieldsSchema = z
  .object({
    name: z.string().trim().min(1).max(100).optional(),
    email: z.string().trim().email().max(200).optional(),
    company: z.string().trim().min(1).max(120).optional(),
    role: z.string().trim().min(1).max(80).optional(),
    teamSize: z.number().int().positive().max(1_000_000).optional(),
    budgetUsd: z.number().nonnegative().max(100_000_000).optional(),
    timelineWeeks: z.number().positive().max(520).optional(),
    needs: z.array(NeedSchema).max(6).optional(),
    isDecisionMaker: z.boolean().optional(),
  })
  .strict();
export type ExtractedFields = z.infer<typeof ExtractedFieldsSchema>;

export const PackageIdSchema = z.enum(PACKAGE_IDS);
export const BillingSchema = z.enum(["standard", "annual_prepay"]);
export const HandoffReasonSchema = z.enum(["low_fit", "enterprise_quote", "user_request", "safety", "other"]);

export const TOOL_NAMES = ["extractLead", "scoreLead", "suggestOffer", "bookSlot", "handoffToHuman"] as const;
export type ToolName = (typeof TOOL_NAMES)[number];

/* ------------------------------ tool inputs ------------------------------ */

export const ToolCallSchema = z.discriminatedUnion("name", [
  z.object({
    name: z.literal("extractLead"),
    args: z.object({ fields: ExtractedFieldsSchema, declined: z.array(UnknownFieldSchema).max(7).optional() }).strict(),
  }),
  z.object({ name: z.literal("scoreLead"), args: z.object({}).strict() }),
  z.object({
    name: z.literal("suggestOffer"),
    args: z.object({ packageId: PackageIdSchema, billing: BillingSchema.default("standard") }).strict(),
  }),
  z.object({ name: z.literal("bookSlot"), args: z.object({ slotId: z.string().min(3).max(40) }).strict() }),
  z.object({
    name: z.literal("handoffToHuman"),
    args: z.object({ reason: HandoffReasonSchema, note: z.string().max(300).optional() }).strict(),
  }),
]);
export type ToolCall = z.infer<typeof ToolCallSchema>;

/* ----------------------------- tool outputs ------------------------------ */

export const SlotSchema = z.object({ id: z.string(), label: z.string(), startsAt: z.string() });
export type Slot = z.infer<typeof SlotSchema>;

export const ExtractLeadOutputSchema = z.object({
  extracted: ExtractedFieldsSchema,
  unknowns: z.array(UnknownFieldSchema),
  declined: z.array(UnknownFieldSchema),
});
export type ExtractLeadOutput = z.infer<typeof ExtractLeadOutputSchema>;

export const ScoreLeadOutputSchema = z.object({
  score: z.number().min(0).max(100),
  tier: z.enum(["hot", "warm", "cold"]),
  qualified: z.boolean(),
  reasons: z.array(z.string()),
  unknowns: z.array(UnknownFieldSchema),
  riskFlags: z.array(z.string()),
  recommendedPackageId: PackageIdSchema,
});
export type ScoreLeadOutput = z.infer<typeof ScoreLeadOutputSchema>;

export const SuggestOfferOutputSchema = z.object({
  package: z.object({
    id: PackageIdSchema,
    name: z.string(),
    priceUsd: z.number().nullable(),
    deliveryWeeks: z.number().nullable(),
    summary: z.string(),
    features: z.array(z.string()),
  }),
  billing: BillingSchema,
  discountPercent: z.number(),
  finalPriceUsd: z.number().nullable(),
  annualPrepayPriceUsd: z.number().nullable(),
  requiresHuman: z.boolean(),
  budgetGapUsd: z.number().nullable(),
  extraNeeds: z.array(NeedSchema),
  slots: z.array(SlotSchema),
});
export type SuggestOfferOutput = z.infer<typeof SuggestOfferOutputSchema>;

export const BookSlotOutputSchema = z.object({ booked: z.literal(true), slot: SlotSchema });
export type BookSlotOutput = z.infer<typeof BookSlotOutputSchema>;

export const HandoffOutputSchema = z.object({
  handoff: z.literal(true),
  ticketId: z.string(),
  reason: HandoffReasonSchema,
});
export type HandoffOutput = z.infer<typeof HandoffOutputSchema>;

/* ------------------------------ model output ----------------------------- */

/** What the LLM must return on every call: strict JSON. Tool calls are validated one by one. */
export const ModelOutputSchema = z.object({
  reply: z.string().max(4000),
  toolCalls: z.array(z.unknown()).max(10).default([]),
  asked: UnknownFieldSchema.optional().catch(undefined),
});
export type ModelOutput = z.infer<typeof ModelOutputSchema>;
