import { PRICING_CONFIG, PACKAGES, recommendPackage, type PackageId } from "./pricing.config";
import { REQUIRED_FIELDS, UNKNOWN_FIELDS, type ExtractedFields, type UnknownField } from "./schemas";
import type { ConversationState, Lead } from "./types";

export const QUESTIONS: Record<UnknownField, string> = {
  needs: "What are you looking to build — for example a website, web app, online store, mobile app, or AI automation?",
  budget: "Roughly what budget do you have in mind for this project (in USD)?",
  timeline: "What's your target timeline — when would you like this to launch?",
  decision_maker: "Are you the person who makes the final decision on this project, or does someone else sign off?",
  email: "What's the best work email to send your proposal and demo invite to?",
  name: "And what's your name?",
  company: "Which company are you with?",
};

export function fieldKnown(f: ExtractedFields, field: UnknownField): boolean {
  switch (field) {
    case "needs":
      return (f.needs?.length ?? 0) > 0;
    case "budget":
      return f.budgetUsd !== undefined;
    case "timeline":
      return f.timelineWeeks !== undefined;
    case "decision_maker":
      return f.isDecisionMaker !== undefined;
    case "email":
      return !!f.email;
    case "name":
      return !!f.name;
    case "company":
      return !!f.company;
  }
}

/** Everything still unknown (the "unknowns to follow up" list stored on the lead). */
export function computeUnknowns(f: ExtractedFields): UnknownField[] {
  return UNKNOWN_FIELDS.filter((u) => !fieldKnown(f, u));
}

/** Next required field to ask about — skips anything the prospect already declined to answer. */
export function nextUnknown(f: ExtractedFields, declined: UnknownField[]): UnknownField | undefined {
  return REQUIRED_FIELDS.find((u) => !fieldKnown(f, u) && !declined.includes(u));
}

export function isReady(f: ExtractedFields, declined: UnknownField[]): boolean {
  return nextUnknown(f, declined) === undefined;
}

export function mergeFields(base: ExtractedFields, add: ExtractedFields): ExtractedFields {
  const out: ExtractedFields = { ...base, ...add };
  if (base.needs || add.needs) out.needs = [...new Set([...(base.needs ?? []), ...(add.needs ?? [])])];
  return out;
}

const FREE_EMAIL_DOMAINS = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "icloud.com", "proton.me", "protonmail.com"];
export function isFreeEmail(email?: string): boolean {
  if (!email) return false;
  return FREE_EMAIL_DOMAINS.includes(email.split("@")[1]?.toLowerCase() ?? "");
}

export const COMPUTED_FLAGS = ["not_decision_maker", "budget_below_package", "free_email_domain"];

export interface ScoreDetail {
  score: number;
  tier: "hot" | "warm" | "cold";
  qualified: boolean;
  reasons: string[];
  computedFlags: string[];
  packageId: PackageId;
  budgetTooLow: boolean;
}

/** Deterministic, explainable scoring — max 100 (budget 30, authority 20, timeline 20, contact 10, company 10, needs 10). */
export function scoreFields(f: ExtractedFields): ScoreDetail {
  const q = PRICING_CONFIG.qualification;
  const rec = recommendPackage(f);
  const pkg = PACKAGES[rec.packageId];
  const refPrice = pkg.priceUsd ?? q.enterpriseMinBudgetUsd;
  const reasons: string[] = [];
  const flags: string[] = [];
  let score = 0;
  let budgetTooLow = false;

  if (f.budgetUsd !== undefined) {
    const ratio = f.budgetUsd / refPrice;
    const pts = ratio >= 1 ? 30 : ratio >= 0.5 ? 18 : ratio >= q.minBudgetRatio ? 8 : 0;
    score += pts;
    reasons.push(`budget covers ${Math.round(ratio * 100)}% of ${pkg.name} (+${pts})`);
    if (ratio < 1) flags.push("budget_below_package");
    if (ratio < q.minBudgetRatio) budgetTooLow = true;
  } else reasons.push("budget unknown (+0)");

  if (f.isDecisionMaker === true) {
    score += 20;
    reasons.push("is the decision maker (+20)");
  } else if (f.isDecisionMaker === false) {
    score += 5;
    flags.push("not_decision_maker");
    reasons.push("not the decision maker (+5)");
  } else reasons.push("decision maker unknown (+0)");

  if (f.timelineWeeks !== undefined) {
    const pts = f.timelineWeeks <= 12 ? 20 : f.timelineWeeks <= 26 ? 12 : 4;
    score += pts;
    reasons.push(`timeline ${f.timelineWeeks} weeks (+${pts})`);
  } else reasons.push("timeline unknown (+0)");

  if (f.email) {
    score += 10;
    reasons.push("contact email provided (+10)");
    if (isFreeEmail(f.email)) flags.push("free_email_domain");
  }
  if (f.company) {
    score += 10;
    reasons.push("company known (+10)");
  }
  if ((f.needs?.length ?? 0) > 0) {
    score += 10;
    reasons.push("clear need (+10)");
  }

  const qualified = score >= q.minScore && !!f.email && (f.needs?.length ?? 0) > 0 && !budgetTooLow;
  const tier = score >= 80 ? "hot" : score >= q.minScore ? "warm" : "cold";
  return { score, tier, qualified, reasons, computedFlags: flags, packageId: rec.packageId, budgetTooLow };
}

export function addFlag(lead: Lead, flag: string) {
  if (!lead.riskFlags.includes(flag)) lead.riskFlags.push(flag);
}

export function syncComputedFlags(lead: Lead, computed: string[]) {
  lead.riskFlags = lead.riskFlags.filter((f) => !COMPUTED_FLAGS.includes(f)).concat(computed);
}

export function declinedOf(state: ConversationState): UnknownField[] {
  return state.declined ?? [];
}
