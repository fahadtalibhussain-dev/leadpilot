import { PRICING_CONFIG } from "./pricing.config";
import type { Slot } from "./schemas";
import type { Store } from "./store/store";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const pad = (n: number) => String(n).padStart(2, "0");

/**
 * Demo slots: the next business days at the configured local hours, minus slots already claimed.
 * Slot ids are deterministic (slot_YYYYMMDD_HH00) so a booking can be claimed atomically.
 */
export async function availableSlots(now: Date, store: Store): Promise<Slot[]> {
  const { utcOffsetMinutes, hoursLocal, slotsOffered, timezone } = PRICING_CONFIG.demo;
  const taken = await store.takenSlots();
  const local = new Date(now.getTime() + utcOffsetMinutes * 60_000);
  let day = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate());
  const out: Slot[] = [];
  for (let i = 0; i < 21 && out.length < slotsOffered; i++) {
    day += 86_400_000;
    const d = new Date(day);
    const dow = d.getUTCDay();
    if (dow === 0 || dow === 6) continue;
    for (const h of hoursLocal) {
      if (out.length >= slotsOffered) break;
      const id = `slot_${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}_${pad(h)}00`;
      if (taken.has(id)) continue;
      const startsAt = new Date(day + h * 3_600_000 - utcOffsetMinutes * 60_000).toISOString();
      const tz = timezone === "Asia/Karachi" ? "PKT" : timezone;
      out.push({
        id,
        label: `${DAYS[dow]} ${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]}, ${pad(h)}:00 ${tz}`,
        startsAt,
      });
    }
  }
  return out;
}
