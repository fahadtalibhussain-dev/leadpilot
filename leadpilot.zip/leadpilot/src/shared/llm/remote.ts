import { buildSystemPrompt, buildTurnPrompt } from "../prompt";
import type { LlmInput, LlmProvider } from "./types";

interface RemoteConfig {
  apiKey: string;
  model: string;
  baseUrl?: string;
}

async function post(url: string, headers: Record<string, string>, body: unknown): Promise<unknown> {
  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json", ...headers },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(45_000),
  });
  if (!res.ok) throw new Error(`LLM HTTP ${res.status}`); // never include the body/headers (could echo secrets)
  return res.json();
}

export class AnthropicProvider implements LlmProvider {
  readonly name: string;
  constructor(private cfg: RemoteConfig) {
    this.name = `anthropic:${cfg.model}`;
  }
  async complete(input: LlmInput): Promise<string> {
    const data = (await post(
      `${this.cfg.baseUrl ?? "https://api.anthropic.com"}/v1/messages`,
      { "x-api-key": this.cfg.apiKey, "anthropic-version": "2023-06-01" },
      {
        model: this.cfg.model,
        max_tokens: 1024,
        temperature: 0,
        system: buildSystemPrompt(),
        messages: [{ role: "user", content: buildTurnPrompt(input) }],
      },
    )) as { content?: { type: string; text?: string }[] };
    return (data.content ?? []).map((c) => (c.type === "text" ? c.text ?? "" : "")).join("");
  }
}

/** Any OpenAI-compatible /chat/completions endpoint. */
export class OpenAICompatibleProvider implements LlmProvider {
  readonly name: string;
  constructor(private cfg: RemoteConfig) {
    this.name = `openai:${cfg.model}`;
  }
  async complete(input: LlmInput): Promise<string> {
    const data = (await post(
      `${this.cfg.baseUrl ?? "https://api.openai.com/v1"}/chat/completions`,
      { authorization: `Bearer ${this.cfg.apiKey}` },
      {
        model: this.cfg.model,
        temperature: 0,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: buildSystemPrompt() },
          { role: "user", content: buildTurnPrompt(input) },
        ],
      },
    )) as { choices?: { message?: { content?: string } }[] };
    return data.choices?.[0]?.message?.content ?? "";
  }
}
