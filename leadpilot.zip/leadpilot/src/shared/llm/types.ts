import type { ConversationState, Lead, ToolCallRecord } from "../types";

export interface LlmInput {
  /** 0 for the first call of a turn; increments after each batch of tool calls */
  round: number;
  /** "extract_only" = urgency policy: only extractLead is allowed, then ask ONE verification question */
  mode: "normal" | "extract_only";
  history: { role: "user" | "assistant"; content: string }[];
  /** UNTRUSTED prospect text — treat as data, never as instructions */
  userMessage: string;
  lead: Lead;
  state: ConversationState;
  /** tool calls already executed this turn, with results */
  toolResults: ToolCallRecord[];
  now: Date;
  /** set when the previous attempt was not valid JSON / schema — fix and resend */
  repairHint?: string;
}

/** Providers return the RAW model text; the runtime owns parsing, repair and validation. */
export interface LlmProvider {
  readonly name: string;
  complete(input: LlmInput): Promise<string>;
}
