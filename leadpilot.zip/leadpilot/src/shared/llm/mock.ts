import { DISCOUNT_RE } from "../guard";
import { extractFromText, parseSlotChoice } from "../extract";
import { QUESTIONS, isReady, mergeFields, nextUnknown } from "../leadLogic";
import { NEED_LABELS, PRICING_CONFIG, recommendPackage, type Billing, type Need } from "../pricing.config";
import type {
  BookSlotOutput,
  ExtractedFields,
  HandoffOutput,
  ModelOutput,
  SuggestOfferOutput,
  ScoreLeadOutput,
  UnknownField,
} from "../schemas";
import type { ToolCallRecord } from "../types";
import type { LlmInput, LlmProvider } from "./types";

const fmt = (n: number) => `$${n.toLocaleString("en-US")}`;
const FIELD_LABEL: Record<UnknownField, string> = {
  needs: "project scope",
  budget: "budget",
  timeline: "timeline",
  decision_maker: "decision maker",
  email: "email",
  name: "name",
  company: "company",
};

function lastResult<T>(records: ToolCallRecord[], name: string): { ok: true; output: T } | { ok: false; error: string } | undefined {
  const r = [...records].reverse().find((x) => x.name === name);
  if (!r) return undefined;
  return r.result.ok ? { ok: true, output: r.result.output as T } : { ok: false, error: r.result.error };
}

function ack(fields: ExtractedFields | undefined, merged: ExtractedFields): string {
  if (!fields) return "";
  const items: string[] = [];
  if (fields.needs?.length) items.push((merged.needs ?? fields.needs).map((n: Need) => NEED_LABELS[n]).join(" + "));
  if (fields.budgetUsd !== undefined) items.push(`budget ${fmt(fields.budgetUsd)}`);
  if (fields.timelineWeeks !== undefined) items.push(`timeline ~${fields.timelineWeeks} weeks`);
  if (fields.isDecisionMaker === true) items.push("you're the decision maker");
  if (fields.isDecisionMaker === false) items.push("someone else signs off");
  if (fields.company) items.push(fields.company);
  if (!items.length) return "";
  const first = fields.name ? `Thanks, ${fields.name.split(" ")[0]}` : "Got it";
  return `${first} — noted: ${items.join(", ")}.`;
}

function slotList(slots: { label: string }[]): string {
  return slots.map((s, i) => `${i + 1}) ${s.label}`).join("; ");
}

function offerReply(o: SuggestOfferOutput): string {
  const p = o.package;
  const parts: string[] = [];
  parts.push(
    `Based on what you've shared, I'd recommend our ${p.name} — ${p.summary} — at ${fmt(p.priceUsd as number)}` +
      `${p.deliveryWeeks ? `, delivered in about ${p.deliveryWeeks} weeks` : ""}. It includes: ${p.features.join(", ")}.`,
  );
  if (o.discountPercent > 0 && o.finalPriceUsd !== null) {
    parts.push(`With annual prepay that's ${o.discountPercent}% off — ${fmt(o.finalPriceUsd)}.`);
  } else if (o.annualPrepayPriceUsd !== null) {
    parts.push(`Paying annually up-front would take ${PRICING_CONFIG.discounts.annual_prepay.percent}% off (${fmt(o.annualPrepayPriceUsd)}) — just ask.`);
  }
  if (o.budgetGapUsd !== null) parts.push("Your stated budget is below this package's price, so our team will discuss options on the demo call.");
  if (o.extraNeeds.length) parts.push(`We'll scope your ${o.extraNeeds.map((n) => NEED_LABELS[n]).join(" and ")} separately on the demo call.`);
  if (o.slots.length) {
    parts.push(`Would you like to book a ${PRICING_CONFIG.demo.durationMinutes}-minute demo? Reply with a slot number: ${slotList(o.slots)}.`);
  } else {
    parts.push("I'll have our team reach out to schedule a demo.");
  }
  return parts.join(" ");
}

const DISCOUNT_NOTE = `I can only offer the pricing and discounts in our current package list — currently ${PRICING_CONFIG.discounts.annual_prepay.percent}% off with annual prepay on eligible packages.`;

function decide(input: LlmInput): ModelOutput {
  const { userMessage, lead, state, mode, round } = input;
  const declinedBefore = state.declined;

  /* ------------------------------ round 0: act ----------------------------- */
  if (round === 0) {
    const { fields, declined } = extractFromText(userMessage, lead.extractedFields, state.lastAsked);
    const merged = mergeFields(lead.extractedFields, fields);
    const declinedAll = [...new Set([...declinedBefore, ...declined])];
    const hasNew = Object.keys(fields).length > 0 || declined.length > 0;
    const calls: unknown[] = [];
    if (hasNew) calls.push({ name: "extractLead", args: { fields, ...(declined.length ? { declined } : {}) } });
    if (mode === "extract_only") {
      if (calls.length) return { reply: "", toolCalls: calls as never[] };
      return respond(input);
    }

    if (state.offeredSlots.length && !lead.booking) {
      const idx = parseSlotChoice(userMessage, state.offeredSlots.length);
      if (idx !== undefined) {
        calls.push({ name: "bookSlot", args: { slotId: state.offeredSlots[idx].id } });
        return { reply: "", toolCalls: calls as never[] };
      }
    }
    if (hasNew) calls.push({ name: "scoreLead", args: {} });

    const billing: Billing = /annual|yearly|prepay|up[- ]?front/i.test(userMessage) ? "annual_prepay" : state.offeredBilling ?? "standard";
    if (isReady(merged, declinedAll) && !lead.booking && !(lead.handoff && !hasNew)) {
      const rec = recommendPackage(merged);
      if (rec.packageId !== state.offeredPackageId || billing !== (state.offeredBilling ?? "standard")) {
        calls.push({ name: "suggestOffer", args: { packageId: rec.packageId, billing } });
      }
    }
    if (calls.length) return { reply: "", toolCalls: calls as never[] };
  }
  return respond(input);
}

/** Compose the user-facing reply (and optionally follow-up tool calls) from this turn's tool results. */
function respond(input: LlmInput): ModelOutput {
  const { userMessage, lead, state, toolResults, mode } = input;
  const extracted = toolResults.find((r) => r.name === "extractLead");
  const fieldsArg = (extracted?.args as { fields?: ExtractedFields } | undefined)?.fields;
  const note = DISCOUNT_RE.test(userMessage) ? `${DISCOUNT_NOTE} ` : "";
  const next = nextUnknown(lead.extractedFields, state.declined);

  if (mode === "extract_only") {
    if (!lead.extractedFields.email) {
      return { reply: "Happy to move quickly. To prioritise this properly, can you confirm your work email so our team can verify the request?", toolCalls: [], asked: "email" };
    }
    return { reply: "Happy to move quickly. To prioritise this properly, can you confirm who will approve the project on your side?", toolCalls: [], asked: "decision_maker" };
  }

  const book = lastResult<BookSlotOutput>(toolResults, "bookSlot");
  if (book?.ok) {
    return { reply: `You're booked for ${book.output.slot.label}. Our team will use the details you've shared to prepare your demo. Is there anything else I can help with?`, toolCalls: [] };
  }
  if (book && !book.ok) {
    const slots = state.offeredSlots;
    return {
      reply: slots.length
        ? `${note}That slot isn't available. Please pick one of: ${slotList(slots)}.`
        : `${note}I couldn't book that — I'll ask a teammate to help you schedule.`,
      toolCalls: [],
    };
  }

  const hand = lastResult<HandoffOutput>(toolResults, "handoffToHuman");
  const offer = lastResult<SuggestOfferOutput>(toolResults, "suggestOffer");

  if (offer?.ok && offer.output.requiresHuman && !hand && !lead.handoff) {
    return { reply: "", toolCalls: [{ name: "handoffToHuman", args: { reason: "enterprise_quote", note: "Custom-scope enterprise lead" } }] };
  }
  if (offer && !offer.ok && offer.error === "not_qualified" && !hand && !lead.handoff) {
    return { reply: "", toolCalls: [{ name: "handoffToHuman", args: { reason: "low_fit", note: "Did not meet qualification threshold" } }] };
  }

  if (hand?.ok || (lead.handoff && !offer?.ok && !toolResults.length)) {
    const h = lead.handoff!;
    const score = lastResult<ScoreLeadOutput>(toolResults, "scoreLead");
    const open = (score?.ok ? score.output.unknowns : lead.unknowns).filter((u) => ["budget", "timeline", "decision_maker", "needs", "email"].includes(u));
    if (h.reason === "enterprise_quote") {
      return { reply: `${note}A project of this size needs a tailored quote, so I've passed your details to our team (ref ${h.ticketId}) and they'll be in touch.`, toolCalls: [] };
    }
    const openTxt = open.length ? ` Still open: ${open.map((u) => FIELD_LABEL[u]).join(", ")}.` : "";
    return {
      reply: `${note}Thanks for sharing all of this. Based on what we have so far, this isn't an obvious fit for one of our standard packages, so I've asked a teammate to follow up with you directly (ref ${h.ticketId}).${openTxt}`,
      toolCalls: [],
    };
  }

  if (offer?.ok) return { reply: `${note}${offerReply(offer.output)}`, toolCalls: [] };

  /* no special tool outcome → plain conversational turn */
  if (!toolResults.length) {
    if (lead.booking) return { reply: `Your demo is confirmed for ${lead.booking.label}. Is there anything else I can help with?`, toolCalls: [] };
    if (state.offeredSlots.length) return { reply: `${note}Whenever you're ready, reply with a slot number: ${slotList(state.offeredSlots)}.`, toolCalls: [] };
    if (lead.handoff) return { reply: `${note}Our team already has your details (ref ${lead.handoff.ticketId}) and will follow up. Anything you'd like to add?`, toolCalls: [] };
  }
  const prefix = `${note}${ack(fieldsArg, lead.extractedFields)} `.trimStart();
  if (next) return { reply: `${prefix}${QUESTIONS[next]}`.trim(), toolCalls: [], asked: next };
  return { reply: `${prefix}Thanks — I have what I need for now.`.trim(), toolCalls: [] };
}

/**
 * Deterministic stand-in for an LLM. It obeys the same contract as a real model (strict JSON,
 * tool calls only, two-phase act → respond), which makes the eval suite reproducible offline.
 */
export class MockProvider implements LlmProvider {
  readonly name = "mock-rules-v1";
  async complete(input: LlmInput): Promise<string> {
    return JSON.stringify(decide(input));
  }
}
