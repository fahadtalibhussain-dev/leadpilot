import { MockProvider } from "./mock";
import { AnthropicProvider, OpenAICompatibleProvider } from "./remote";
import type { LlmProvider } from "./types";

export type { LlmInput, LlmProvider } from "./types";
export { MockProvider } from "./mock";

/** Choose the provider from env. Falls back to the deterministic mock when no key is configured. */
export function createProvider(env: Record<string, string | undefined> = process.env): LlmProvider {
  const kind = (env.LLM_PROVIDER ?? "mock").toLowerCase();
  const apiKey = env.LLM_API_KEY ?? "";
  if (kind === "mock" || !apiKey) return new MockProvider();
  const model = env.LLM_MODEL ?? "claude-sonnet-5-5";
  if (kind === "anthropic") return new AnthropicProvider({ apiKey, model, baseUrl: env.LLM_BASE_URL });
  if (kind === "openai") return new OpenAICompatibleProvider({ apiKey, model, baseUrl: env.LLM_BASE_URL });
  return new MockProvider();
}
