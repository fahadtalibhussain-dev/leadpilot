import { NEED_LABELS, PRICING_CONFIG, discountFor, finalPrice, getPackage, recommendPackage } from "./pricing.config";
import type { Lead } from "./types";

export class ProposalError extends Error {}

const fmt = (n: number) => `$${n.toLocaleString("en-US")}`;

/**
 * Deterministic, config-grounded proposal. Every number and feature comes from pricing.config.ts;
 * anything uncertain is listed in `assumptions` instead of being papered over.
 */
export function generateProposal(lead: Lead): { proposalMarkdown: string; assumptions: string[] } {
  if (!["qualified", "proposal_sent", "booked", "won"].includes(lead.stage)) {
    throw new ProposalError("lead_not_qualified");
  }
  const f = lead.extractedFields;
  const packageId = lead.offer?.packageId ?? recommendPackage(f).packageId;
  const pkg = getPackage(packageId);
  const billing = lead.offer?.billing ?? "standard";
  const pct = discountFor(pkg, billing);
  const final = finalPrice(pkg, pct);
  const rec = recommendPackage(f);

  const assumptions: string[] = [`Pricing and scope follow Spacenos price list v${PRICING_CONFIG.version}; final scope is confirmed on the demo call.`];
  if (f.budgetUsd === undefined) assumptions.push("Budget was not shared; no budget fit has been assessed.");
  else if (pkg.priceUsd !== null && f.budgetUsd < pkg.priceUsd) assumptions.push(`Stated budget (${fmt(f.budgetUsd)}) is below the package price; options to be discussed.`);
  if (f.timelineWeeks === undefined) assumptions.push("Target timeline was not shared.");
  else if (pkg.deliveryWeeks !== null && f.timelineWeeks < pkg.deliveryWeeks) {
    assumptions.push(`Requested timeline (${f.timelineWeeks} weeks) is shorter than standard delivery (${pkg.deliveryWeeks} weeks); a date is not guaranteed.`);
  }
  if (f.isDecisionMaker !== true) assumptions.push("The approving decision maker has not been confirmed.");
  if (rec.extraNeeds.length) assumptions.push(`Additional needs (${rec.extraNeeds.map((n) => NEED_LABELS[n]).join(", ")}) are not included and need separate scoping.`);
  if (pkg.priceUsd === null) assumptions.push("This is a custom-scope engagement: pricing is a custom quote prepared by our team.");

  const lines: string[] = [
    `# Proposal${f.company ? ` for ${f.company}` : ""}`,
    "",
    `Prepared for: ${f.name ?? "Prospect"}${f.role ? ` (${f.role})` : ""}`,
    "",
    "## Recommended package",
    `**${pkg.name}** — ${pkg.summary}.`,
    "",
    "## Included",
    ...pkg.features.map((x) => `- ${x}`),
    "",
    "## Timeline",
    pkg.deliveryWeeks !== null ? `Standard delivery: about ${pkg.deliveryWeeks} weeks from kickoff.` : "To be defined after a discovery workshop.",
    "",
    "## Investment",
  ];
  if (pkg.priceUsd === null) lines.push("Custom quote — our team will prepare pricing after discovery.");
  else {
    lines.push(`Package price: ${fmt(pkg.priceUsd)} (${PRICING_CONFIG.currency}).`);
    if (pct > 0 && final !== null) lines.push(`Annual prepay (${pct}% off): ${fmt(final)}.`);
    else if (pkg.discountEligible) lines.push(`Annual prepay option: ${PRICING_CONFIG.discounts.annual_prepay.percent}% off, if paid up-front.`);
  }
  lines.push("", "## Next steps", lead.booking ? `Demo booked: ${lead.booking.label}.` : "Book a 30-minute demo with our team.", "", "## Assumptions", ...assumptions.map((a) => `- ${a}`));

  return { proposalMarkdown: lines.join("\n"), assumptions };
}
