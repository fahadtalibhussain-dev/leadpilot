import { allowedAmounts, allowedPercents } from "./pricing.config";

/** Marker embedded in the real system prompt — if it ever shows up in a reply, we leaked. */
export const PROMPT_MARKER = "LEADPILOT_SYSTEM_PROMPT_v1";

export type GuardKind = "ok" | "injection" | "leak" | "urgency";
export interface GuardResult {
  kind: GuardKind;
  flags: string[];
}

const LEAK = [
  /system\s*prompt/i,
  /(show|reveal|print|repeat|tell|give|share|dump|what(?:'s| is| are)).{0,40}(instructions|api[ _-]?keys?|secrets?|tokens?|passwords?|env(?:ironment)? variables?|credentials|config(?:uration)?\b)/i,
  /\bapi[ _-]?keys?\b/i,
  /\bsk-[a-z0-9]{6,}/i,
  /(initial|original|hidden) (instructions|prompt)/i,
];

const INJECTION = [
  /ignore\s+(?:all\s+|the\s+|any\s+|your\s+|previous\s+|prior\s+|above\s+)*(?:instructions|rules|pricing|prices|config|configuration|prompt|policy|policies)/i,
  /disregard\s+.{0,30}(instructions|pricing|config|rules|policy)/i,
  /(give|grant|get)\s+me\s+(?:an?\s+)?(?:admin|root|full|super)\b/i,
  /\badmin(?:istrator)?\s+(access|rights|privileges|panel|mode)/i,
  /\byou are now\b/i,
  /developer mode|jailbreak|\bDAN\b/i,
  /override\s+.{0,30}(pricing|price|config|policy|rules)/i,
  /pretend\s+(?:you|to be)\b/i,
  /act as\s+(?:an?\s+)?(?:admin|developer|system|root)/i,
  /\b(?:new|updated)\s+(?:instructions|rules)\s*:/i,
  /\b(?:set|mark|change|move|update)\s+(?:my|the|this)\s+(?:lead|stage|status|pipeline|score)\b/i,
];

const URGENCY = [
  /\b(?:close|sign|pay|decide|buy|finali[sz]e|book)\b.{0,20}\b(?:today|right now|immediately|tonight|this hour)\b/i,
  /\b(?:right now|immediately)\b.{0,20}\b(?:close|sign|pay|buy)\b/i,
  /\burgent(?:ly)?\b/i,
];

export const DISCOUNT_RE = /\b\d{1,3}\s?%\s*(?:discount|off)\b|\bdiscount\b|\bhalf price\b|\bfor free\b/i;

/** Deterministic pre-LLM screening. Injection / leak attempts never reach the model. */
export function classifyInput(text: string): GuardResult {
  const flags: string[] = [];
  if (DISCOUNT_RE.test(text)) flags.push("discount_request");
  if (LEAK.some((r) => r.test(text))) return { kind: "leak", flags: [...flags, "prompt_leak_attempt"] };
  if (INJECTION.some((r) => r.test(text))) return { kind: "injection", flags: [...flags, "prompt_injection"] };
  if (URGENCY.some((r) => r.test(text))) return { kind: "urgency", flags: [...flags, "urgency_claim"] };
  return { kind: "ok", flags };
}

function secretValues(): string[] {
  return Object.entries(process.env)
    .filter(([k, v]) => /(KEY|SECRET|TOKEN|PASSWORD|PRIVATE)/i.test(k) && typeof v === "string" && v.length >= 8)
    .map(([, v]) => v as string);
}

export interface ReplyCheckCtx {
  /** numbers the user (or the lead record) already stated — echoing those is fine */
  userAmounts: number[];
}

/**
 * Output-side grounding + leak check. Returns the list of violations found in a model reply:
 *   leak | ungrounded_price:<n> | ungrounded_discount:<n>
 */
export function checkReply(reply: string, ctx: ReplyCheckCtx): string[] {
  const v: string[] = [];
  if (reply.includes(PROMPT_MARKER) || /\bsk-[A-Za-z0-9_-]{8,}/.test(reply) || secretValues().some((s) => reply.includes(s))) {
    v.push("leak");
  }
  const okAmounts = allowedAmounts();
  const seen = new Set<number>();
  const amountRes = [
    /\$\s?(\d[\d,]*(?:\.\d+)?)\s?(k|K)?/g,
    /\b(\d[\d,]*(?:\.\d+)?)\s?(k|K)?\s?(?:USD|usd|dollars)\b/g,
  ];
  for (const re of amountRes) {
    for (const m of reply.matchAll(re)) {
      const n = Math.round(parseFloat(m[1].replace(/,/g, "")) * (m[2] ? 1000 : 1));
      if (Number.isNaN(n) || seen.has(n)) continue;
      seen.add(n);
      if (!okAmounts.has(n) && !ctx.userAmounts.includes(n)) v.push(`ungrounded_price:${n}`);
    }
  }
  const okPct = allowedPercents();
  for (const m of reply.matchAll(/(\d+(?:\.\d+)?)\s?%/g)) {
    const n = parseFloat(m[1]);
    if (!okPct.has(n)) v.push(`ungrounded_discount:${n}`);
  }
  return v;
}
