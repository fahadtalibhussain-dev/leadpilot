"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { Badge, STAGE_TONE } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface ToolCall { name: string; result: { ok: boolean; error?: string; output?: { slots?: { id: string; label: string }[] } } }
interface Msg { role: "user" | "assistant"; content: string; toolCalls?: ToolCall[] }
interface LeadView {
  stage: string;
  score: number;
  unknowns: string[];
  extractedFields: Record<string, unknown>;
  riskFlags: string[];
}

const STORAGE_KEY = "leadpilot.conversationId";
const UNKNOWN_LABEL: Record<string, string> = { needs: "Project scope", budget: "Budget", timeline: "Timeline", decision_maker: "Decision maker", email: "Email", name: "Name", company: "Company" };
const TRACKED = ["needs", "budget", "timeline", "decision_maker", "email"];

export default function ChatPage() {
  const [conversationId, setConversationId] = useState<string>();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [lead, setLead] = useState<LeadView>();
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const [showTools, setShowTools] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  const start = useCallback(async () => {
    const r = await fetch("/api/chat", { method: "POST", body: JSON.stringify({ action: "start" }) });
    const d = await r.json();
    setConversationId(d.conversationId);
    setMessages([{ role: "assistant", content: d.reply }]);
    setLead(undefined);
    try { localStorage.setItem(STORAGE_KEY, d.conversationId); } catch {}
  }, []);

  useEffect(() => {
    (async () => {
      let saved: string | null = null;
      try { saved = localStorage.getItem(STORAGE_KEY); } catch {}
      if (saved) {
        const r = await fetch(`/api/conversation?id=${saved}`);
        if (r.ok) {
          const d = await r.json();
          setConversationId(saved);
          setMessages(d.messages);
          setLead(d);
          return;
        }
      }
      await start();
    })().catch(() => setError("Could not start the chat. Please refresh."));
  }, [start]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, busy]);

  async function send(text: string) {
    const message = text.trim();
    if (!message || busy || !conversationId) return;
    setInput("");
    setError(undefined);
    setBusy(true);
    setMessages((m) => [...m, { role: "user", content: message }]);
    try {
      const r = await fetch("/api/chat", { method: "POST", body: JSON.stringify({ conversationId, message }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "error");
      setMessages((m) => [...m, { role: "assistant", content: d.reply, toolCalls: d.toolCalls }]);
      setLead(d);
    } catch (e) {
      const code = (e as Error).message;
      setError(code === "rate_limited" ? "You're sending messages too fast — wait a moment." : code === "message_too_long" ? "That message is too long (max 2,000 characters)." : "Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  const lastSlots = [...messages].reverse().flatMap((m) => m.toolCalls ?? []).find((t) => t.name === "suggestOffer" && t.result.ok)?.result.output?.slots;
  const booked = lead?.stage === "booked";
  const known = (f: string) => !(lead?.unknowns ?? TRACKED).includes(f);

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
      <Card className="flex h-[calc(100vh-130px)] min-h-[480px] flex-col">
        <div className="flex-1 space-y-3 overflow-y-auto p-4" aria-live="polite">
          {messages.map((m, i) => (
            <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2 text-sm ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                {m.content}
                {showTools && m.toolCalls?.length ? (
                  <pre className="mt-2 overflow-x-auto rounded bg-slate-900 p-2 text-[11px] text-slate-100">{JSON.stringify(m.toolCalls.map((t) => ({ tool: t.name, ok: t.result.ok })), null, 1)}</pre>
                ) : null}
              </div>
            </div>
          ))}
          {busy && <div className="text-sm text-muted-foreground">LeadPilot is typing…</div>}
          <div ref={endRef} />
        </div>
        {lastSlots?.length && !booked ? (
          <div className="flex flex-wrap gap-2 border-t border-border px-4 py-2">
            {lastSlots.map((s, i) => (
              <Button key={s.id} size="sm" variant="outline" disabled={busy} onClick={() => send(`slot ${i + 1}`)}>{s.label}</Button>
            ))}
          </div>
        ) : null}
        {error && <div className="px-4 pb-1 text-sm text-red-600" role="alert">{error}</div>}
        <form className="flex gap-2 border-t border-border p-3" onSubmit={(e) => { e.preventDefault(); send(input); }}>
          <input
            className="h-10 flex-1 rounded-lg border border-border px-3 text-sm outline-none focus:border-primary"
            placeholder={booked ? "You're booked — ask anything else" : "Type your message…"}
            value={input}
            maxLength={2000}
            onChange={(e) => setInput(e.target.value)}
            aria-label="Message"
          />
          <Button type="submit" disabled={busy || !input.trim()}>Send</Button>
        </form>
      </Card>

      <aside className="space-y-4">
        <Card className="p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold">Your request</h2>
            {lead && <Badge tone={STAGE_TONE[lead.stage]}>{lead.stage.replace("_", " ")}</Badge>}
          </div>
          <ul className="space-y-1.5 text-sm">
            {TRACKED.map((f) => (
              <li key={f} className="flex items-center gap-2">
                <span className={known(f) && lead ? "text-emerald-600" : "text-slate-300"} aria-hidden>●</span>
                <span className={known(f) && lead ? "" : "text-muted-foreground"}>{UNKNOWN_LABEL[f]}</span>
              </li>
            ))}
          </ul>
          {booked && <p className="mt-3 rounded-lg bg-emerald-50 p-2 text-sm text-emerald-800">Demo booked — check the chat for the time.</p>}
        </Card>
        <Card className="space-y-2 p-4 text-sm">
          <label className="flex items-center gap-2 text-muted-foreground">
            <input type="checkbox" checked={showTools} onChange={(e) => setShowTools(e.target.checked)} /> Show tool calls
          </label>
          <Button variant="outline" size="sm" onClick={() => start()}>Start new conversation</Button>
        </Card>
      </aside>
    </div>
  );
}
