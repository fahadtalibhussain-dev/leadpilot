"use client";
import { useCallback, useEffect, useState } from "react";
import { Badge, STAGE_TONE } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { authHeader, firebaseConfigured, loginWithGoogle, logout, watchAuth } from "@/lib/firebase-client";

const STAGES = ["new", "qualified", "proposal_sent", "booked", "won", "lost"] as const;

interface LeadRow {
  id: string;
  stage: string;
  score: number;
  tier: string;
  extractedFields: Record<string, unknown>;
  unknowns: string[];
  riskFlags: string[];
  notes: { at: number; by: string; text: string }[];
  offer?: { packageId: string; finalPriceUsd: number | null };
  booking?: { label: string };
  handoff?: { reason: string; ticketId: string };
  updatedAt: number;
}

export default function AdminPage() {
  const [authed, setAuthed] = useState(!firebaseConfigured);
  const [ready, setReady] = useState(!firebaseConfigured);
  const [leads, setLeads] = useState<LeadRow[]>([]);
  const [selId, setSelId] = useState<string>();
  const [note, setNote] = useState("");
  const [proposal, setProposal] = useState<{ proposalMarkdown: string; assumptions: string[] }>();
  const [error, setError] = useState<string>();

  useEffect(() => {
    if (!firebaseConfigured) return;
    return watchAuth((u) => { setAuthed(!!u); setReady(true); });
  }, []);

  const api = useCallback(async (url: string, init?: RequestInit) => {
    const r = await fetch(url, { ...init, headers: { "content-type": "application/json", ...(await authHeader()) } });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error ?? "error");
    return d;
  }, []);

  const load = useCallback(async () => {
    try { setLeads((await api("/api/admin/leads")).leads); setError(undefined); }
    catch (e) { setError((e as Error).message === "not_admin" ? "This account is not an admin." : "Could not load leads."); }
  }, [api]);

  useEffect(() => { if (authed) load(); }, [authed, load]);

  const sel = leads.find((l) => l.id === selId);

  async function patch(body: object) {
    try { await api("/api/admin/leads", { method: "PATCH", body: JSON.stringify({ id: selId, ...body }) }); await load(); }
    catch { setError("Update failed."); }
  }
  async function makeProposal() {
    setProposal(undefined);
    try { setProposal(await api("/api/admin/proposal", { method: "POST", body: JSON.stringify({ leadId: selId }) })); setError(undefined); }
    catch (e) { setError((e as Error).message === "lead_not_qualified" ? "Lead must be qualified before a proposal can be generated." : "Could not generate proposal."); }
  }

  if (!ready) return <p className="text-muted-foreground">Loading…</p>;
  if (!authed) {
    return (
      <Card className="mx-auto max-w-sm space-y-3 p-6 text-center">
        <h1 className="text-lg font-semibold">Admin sign-in</h1>
        <p className="text-sm text-muted-foreground">Sign in with an authorised Spacenos account.</p>
        <Button onClick={() => loginWithGoogle()}>Sign in with Google</Button>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Sales pipeline</h1>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load}>Refresh</Button>
          {firebaseConfigured && <Button variant="ghost" size="sm" onClick={() => logout()}>Sign out</Button>}
        </div>
      </div>
      {error && <p className="text-sm text-red-600" role="alert">{error}</p>}

      <div className="grid gap-3 md:grid-cols-3 lg:grid-cols-6">
        {STAGES.map((s) => (
          <Card key={s} className="p-3">
            <div className="mb-2 flex items-center justify-between text-xs font-medium uppercase text-muted-foreground">
              {s.replace("_", " ")} <span>{leads.filter((l) => l.stage === s).length}</span>
            </div>
            <div className="space-y-2">
              {leads.filter((l) => l.stage === s).map((l) => (
                <button key={l.id} onClick={() => { setSelId(l.id); setProposal(undefined); }}
                  className={`w-full rounded-lg border p-2 text-left text-sm hover:bg-muted ${selId === l.id ? "border-primary" : "border-border"}`}>
                  <div className="truncate font-medium">{(l.extractedFields.name as string) ?? "Unknown"}</div>
                  <div className="truncate text-xs text-muted-foreground">{(l.extractedFields.company as string) ?? "—"} · score {l.score}</div>
                  {l.riskFlags.length > 0 && <div className="mt-1 text-xs text-amber-700">⚠ {l.riskFlags.length} flag(s)</div>}
                </button>
              ))}
            </div>
          </Card>
        ))}
      </div>

      {sel && (
        <Card className="grid gap-6 p-5 lg:grid-cols-2">
          <div className="space-y-3 text-sm">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold">{(sel.extractedFields.name as string) ?? "Unknown lead"}</h2>
              <Badge tone={STAGE_TONE[sel.stage]}>{sel.stage.replace("_", " ")}</Badge>
              <Badge tone={sel.tier === "hot" ? "red" : sel.tier === "warm" ? "amber" : "slate"}>{sel.tier} · {sel.score}</Badge>
            </div>
            <pre className="overflow-x-auto rounded-lg bg-muted p-3 text-xs">{JSON.stringify(sel.extractedFields, null, 2)}</pre>
            <div><span className="font-medium">Unknowns to follow up:</span> {sel.unknowns.length ? sel.unknowns.join(", ") : "none"}</div>
            <div className="flex flex-wrap gap-1">{sel.riskFlags.map((f) => <Badge key={f} tone="amber">{f}</Badge>)}</div>
            {sel.offer && <div>Offer: <b>{sel.offer.packageId}</b>{sel.offer.finalPriceUsd !== null && ` · $${sel.offer.finalPriceUsd.toLocaleString()}`}</div>}
            {sel.booking && <div>Demo: <b>{sel.booking.label}</b></div>}
            {sel.handoff && <div>Human handoff: {sel.handoff.reason} ({sel.handoff.ticketId})</div>}
          </div>
          <div className="space-y-3 text-sm">
            <label className="block">
              <span className="font-medium">Override stage</span>
              <select className="mt-1 h-10 w-full rounded-lg border border-border px-2" value={sel.stage} onChange={(e) => patch({ stage: e.target.value })}>
                {STAGES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
              </select>
            </label>
            <div>
              <span className="font-medium">Notes</span>
              <ul className="my-1 space-y-1">{sel.notes.map((n, i) => <li key={i} className="rounded bg-muted p-2 text-xs"><b>{n.by}</b>: {n.text}</li>)}</ul>
              <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); if (note.trim()) { patch({ note }); setNote(""); } }}>
                <input className="h-10 flex-1 rounded-lg border border-border px-3" placeholder="Add a note…" value={note} onChange={(e) => setNote(e.target.value)} />
                <Button type="submit" variant="outline">Add</Button>
              </form>
            </div>
            <Button onClick={makeProposal}>Generate proposal</Button>
            {proposal && (
              <div className="space-y-2">
                <pre className="max-h-72 overflow-auto whitespace-pre-wrap rounded-lg bg-muted p-3 text-xs">{proposal.proposalMarkdown}</pre>
                <p className="text-xs text-muted-foreground">{proposal.assumptions.length} assumption(s) listed in the proposal.</p>
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
}
