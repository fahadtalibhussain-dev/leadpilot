import { ProposalError, generateProposal } from "@/shared/proposal";
import { errorResponse, getStore, requireAdmin } from "@/lib/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** POST { leadId } → { proposalMarkdown, assumptions[] } */
export async function POST(req: Request) {
  try {
    await requireAdmin(req);
    const { leadId } = (await req.json()) as { leadId?: string };
    if (!leadId) return Response.json({ error: "leadId_required" }, { status: 400 });
    const lead = await (await getStore()).getLead(leadId);
    if (!lead) return Response.json({ error: "lead_not_found" }, { status: 404 });
    return Response.json(generateProposal(lead));
  } catch (e) {
    if (e instanceof ProposalError) return Response.json({ error: e.message }, { status: 409 });
    return errorResponse(e);
  }
}
