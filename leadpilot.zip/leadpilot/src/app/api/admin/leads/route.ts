import { logEvent } from "@/shared/logger";
import { StageSchema } from "@/shared/schemas";
import { errorResponse, getStore, requireAdmin } from "@/lib/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await requireAdmin(req);
    const store = await getStore();
    return Response.json({ leads: await store.listLeads(200) });
  } catch (e) {
    return errorResponse(e);
  }
}

/** PATCH { id, stage?, note? } — admin override of the pipeline stage and/or add a note. */
export async function PATCH(req: Request) {
  try {
    const admin = await requireAdmin(req);
    const body = (await req.json()) as { id?: string; stage?: string; note?: string };
    if (!body.id) return Response.json({ error: "id_required" }, { status: 400 });
    const store = await getStore();
    const lead = await store.getLead(body.id);
    if (!lead) return Response.json({ error: "lead_not_found" }, { status: 404 });
    if (body.stage !== undefined) {
      const stage = StageSchema.safeParse(body.stage);
      if (!stage.success) return Response.json({ error: "invalid_stage" }, { status: 400 });
      logEvent("info", "admin_stage_override", { leadId: lead.id, from: lead.stage, to: stage.data, by: admin.email });
      lead.stage = stage.data;
    }
    if (body.note?.trim()) {
      lead.notes.push({ at: Date.now(), by: admin.email, text: body.note.trim().slice(0, 1000) });
    }
    lead.updatedAt = Date.now();
    await store.saveLead(lead);
    return Response.json({ lead });
  } catch (e) {
    return errorResponse(e);
  }
}
