import { GREETING, chatTurn, createConversation } from "@/shared/agent";
import { errorResponse, getProvider, getStore, rateLimit } from "@/lib/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** POST { action: "start" } → new conversation.  POST { conversationId, message } → one chat turn. */
export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
    if (!rateLimit(`chat:${ip}`)) return Response.json({ error: "rate_limited" }, { status: 429 });
    const body = (await req.json().catch(() => ({}))) as { action?: string; conversationId?: string; message?: string };
    const store = await getStore();

    if (body.action === "start") {
      const { conversationId } = await createConversation(store);
      return Response.json({ conversationId, reply: GREETING });
    }
    if (!body.conversationId) return Response.json({ error: "conversationId_required" }, { status: 400 });
    const result = await chatTurn({ store, llm: getProvider() }, body.conversationId, body.message ?? "");
    return Response.json({
      conversationId: body.conversationId,
      reply: result.reply,
      toolCalls: result.toolCalls,
      stage: result.stage,
      score: result.score,
      unknowns: result.unknowns,
      extractedFields: result.extractedFields,
      riskFlags: result.riskFlags,
    });
  } catch (e) {
    return errorResponse(e);
  }
}
