import { chaosProvider, runEval } from "@/shared/eval/harness";
import { DEFAULT_SUITE_ID, TESTCASES, type EvalCase } from "@/shared/eval/testcases";
import { errorResponse, getProvider, getStore, requireAdmin } from "@/lib/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** POST { suiteId?, chaos? } → { report, failures } ; the report is also saved to eval_reports/{id}. */
export async function POST(req: Request) {
  try {
    await requireAdmin(req);
    const body = (await req.json().catch(() => ({}))) as { suiteId?: string; chaos?: boolean };
    const store = await getStore();
    const suiteId = body.suiteId ?? DEFAULT_SUITE_ID;
    let suite = TESTCASES;
    const saved = await store.getEvalSuite(suiteId);
    if (saved) suite = saved.testcases as EvalCase[];
    else if (suiteId === DEFAULT_SUITE_ID) await store.saveEvalSuite({ id: suiteId, name: "Default 20 scripted conversations", testcases: TESTCASES });
    else return Response.json({ error: "suite_not_found" }, { status: 404 });

    const base = getProvider();
    const report = await runEval({ suite, suiteId, llm: body.chaos ? chaosProvider(base) : base });
    await store.saveEvalReport({ id: `${suiteId}-${report.createdAt}`, suiteId, createdAt: report.createdAt, metrics: report.metrics, failures: report.failures });
    return Response.json({ report, failures: report.failures });
  } catch (e) {
    return errorResponse(e);
  }
}
