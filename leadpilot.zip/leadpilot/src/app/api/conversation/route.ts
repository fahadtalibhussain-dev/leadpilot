import { errorResponse, getStore } from "@/lib/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Restore a conversation after a page reload (the conversation id is an unguessable random id). */
export async function GET(req: Request) {
  try {
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return Response.json({ error: "id_required" }, { status: 400 });
    const store = await getStore();
    const conv = await store.getConversation(id);
    if (!conv) return Response.json({ error: "conversation_not_found" }, { status: 404 });
    const lead = await store.getLead(conv.leadId);
    return Response.json({
      messages: conv.messages.map((m) => ({ role: m.role, content: m.content, toolCalls: m.toolCalls })),
      stage: lead?.stage ?? "new",
      score: lead?.score ?? 0,
      unknowns: lead?.unknowns ?? [],
      extractedFields: lead?.extractedFields ?? {},
      riskFlags: lead?.riskFlags ?? [],
    });
  } catch (e) {
    return errorResponse(e);
  }
}
