"use client";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { authHeader } from "@/lib/firebase-client";

interface Report {
  llm: string;
  metrics: { cases: number; passed: number; extractionAccuracy: number; hallucinationCount: number; bookingRate: number; redTeamPassRate: number; stageAccuracy: number; repairs: number };
  results: { id: string; title: string; passed: boolean; extractionCorrect: number; extractionExpected: number; stage: string; booked: boolean; failures: string[] }[];
  failures: { caseId: string; type: string; detail: string }[];
}

const pct = (n: number) => `${(n * 100).toFixed(1)}%`;

export default function EvalPage() {
  const [report, setReport] = useState<Report>();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();

  async function run(chaos: boolean) {
    setBusy(true);
    setError(undefined);
    try {
      const r = await fetch("/api/eval", { method: "POST", headers: { "content-type": "application/json", ...(await authHeader()) }, body: JSON.stringify({ chaos }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      setReport(d.report);
    } catch (e) {
      setError(`Eval failed: ${(e as Error).message}`);
    } finally {
      setBusy(false);
    }
  }

  const m = report?.metrics;
  const tiles = m && [
    ["Extraction accuracy", pct(m.extractionAccuracy)],
    ["Hallucinations", String(m.hallucinationCount)],
    ["Booking rate", pct(m.bookingRate)],
    ["Red-team pass", pct(m.redTeamPassRate)],
    ["Cases passed", `${m.passed}/${m.cases}`],
    ["JSON auto-repairs", String(m.repairs)],
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-xl font-semibold">Eval harness</h1>
        <div className="flex gap-2">
          <Button onClick={() => run(false)} disabled={busy}>{busy ? "Running…" : "Run 20 conversations"}</Button>
          <Button variant="outline" onClick={() => run(true)} disabled={busy}>Run with corrupted JSON</Button>
        </div>
      </div>
      {error && <p className="text-sm text-red-600" role="alert">{error}</p>}
      {!report && !busy && <p className="text-sm text-muted-foreground">Runs 20 scripted conversations (including red-team attacks) against the live agent and scores them.</p>}
      {report && tiles && (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-6">
            {tiles.map(([k, v]) => (
              <Card key={k} className="p-3">
                <div className="text-xs text-muted-foreground">{k}</div>
                <div className="text-xl font-semibold">{v}</div>
              </Card>
            ))}
          </div>
          <p className="text-xs text-muted-foreground">Provider: {report.llm}</p>
          <Card className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-border text-left text-xs text-muted-foreground">
                <tr><th className="p-3">Case</th><th>Result</th><th>Extraction</th><th>Stage</th><th>Booked</th></tr>
              </thead>
              <tbody>
                {report.results.map((r) => (
                  <tr key={r.id} className="border-b border-border last:border-0 align-top">
                    <td className="p-3"><div className="font-medium">{r.id}</div><div className="text-xs text-muted-foreground">{r.title}</div>
                      {r.failures.map((f, i) => <div key={i} className="text-xs text-red-600">{f}</div>)}</td>
                    <td><Badge tone={r.passed ? "green" : "red"}>{r.passed ? "pass" : "fail"}</Badge></td>
                    <td>{r.extractionCorrect}/{r.extractionExpected}</td>
                    <td>{r.stage}</td>
                    <td>{r.booked ? "yes" : "no"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </>
      )}
    </div>
  );
}
