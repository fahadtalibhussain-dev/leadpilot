import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "LeadPilot — AI sales agent",
  description: "Qualify inbound leads, get a grounded package suggestion and book a demo.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="border-b border-border bg-white">
          <nav className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
            <Link href="/" className="font-semibold tracking-tight">
              Lead<span className="text-primary">Pilot</span>
            </Link>
            <div className="flex gap-5 text-sm text-muted-foreground">
              <Link href="/" className="hover:text-slate-900">Chat</Link>
              <Link href="/admin" className="hover:text-slate-900">Pipeline</Link>
              <Link href="/eval" className="hover:text-slate-900">Eval</Link>
            </div>
          </nav>
        </header>
        <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
