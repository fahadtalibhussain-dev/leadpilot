"use client";
import { getApp, getApps, initializeApp } from "firebase/app";
import { GoogleAuthProvider, getAuth, onAuthStateChanged, signInWithPopup, signOut, type User } from "firebase/auth";

const cfg = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

export const firebaseConfigured = !!cfg.apiKey && !!cfg.projectId;

function auth() {
  const app = getApps().length ? getApp() : initializeApp(cfg);
  return getAuth(app);
}

export const loginWithGoogle = () => signInWithPopup(auth(), new GoogleAuthProvider());
export const logout = () => signOut(auth());
export const watchAuth = (cb: (u: User | null) => void) => onAuthStateChanged(auth(), cb);

/** Authorization header for admin API calls (empty in demo mode). */
export async function authHeader(): Promise<Record<string, string>> {
  if (!firebaseConfigured) return {};
  const u = auth().currentUser;
  return u ? { authorization: `Bearer ${await u.getIdToken()}` } : {};
}
