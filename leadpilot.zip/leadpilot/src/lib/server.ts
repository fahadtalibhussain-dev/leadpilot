import { createProvider } from "@/shared/llm";
import type { LlmProvider } from "@/shared/llm/types";
import { MemoryStore } from "@/shared/store/memory-store";
import type { Store } from "@/shared/store/store";

/**
 * Server-side wiring for the Next.js API routes.
 *  - FIREBASE_SERVICE_ACCOUNT_JSON set  → Firestore + Firebase Auth (production)
 *  - not set                            → in-memory store + open admin (DEMO MODE, local only)
 */

const g = globalThis as unknown as { __lp_store?: Store; __lp_firebase?: boolean };

export function isFirebaseMode(): boolean {
  return !!process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
}

async function adminApp() {
  const { getApps, initializeApp, cert } = await import("firebase-admin/app");
  if (getApps().length) return getApps()[0];
  return initializeApp({ credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON as string)) });
}

export async function getStore(): Promise<Store> {
  if (g.__lp_store) return g.__lp_store;
  if (isFirebaseMode()) {
    await adminApp();
    const { getFirestore } = await import("firebase-admin/firestore");
    const { FirestoreStore } = await import("@/shared/store/firestore-store");
    g.__lp_store = new FirestoreStore(getFirestore());
  } else {
    g.__lp_store = new MemoryStore();
  }
  return g.__lp_store;
}

export function getProvider(): LlmProvider {
  return createProvider();
}

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

/** Admin gate: Firebase ID token with `admin` claim or an email in ADMIN_EMAILS. Open in demo mode. */
export async function requireAdmin(req: Request): Promise<{ email: string }> {
  if (!isFirebaseMode()) return { email: "demo-admin@local" };
  const token = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) throw new HttpError(401, "missing_token");
  await adminApp();
  const { getAuth } = await import("firebase-admin/auth");
  let decoded;
  try {
    decoded = await getAuth().verifyIdToken(token);
  } catch {
    throw new HttpError(401, "invalid_token");
  }
  const allow = (process.env.ADMIN_EMAILS ?? "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
  const email = (decoded.email ?? "").toLowerCase();
  if (decoded.admin === true || (decoded.email_verified && allow.includes(email))) return { email: email || "admin" };
  throw new HttpError(403, "not_admin");
}

/** Tiny per-IP sliding-window limiter (per server instance) for the public chat endpoint. */
const hits = new Map<string, number[]>();
export function rateLimit(key: string, max = 30, windowMs = 60_000): boolean {
  const now = Date.now();
  const arr = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (arr.length >= max) {
    hits.set(key, arr);
    return false;
  }
  arr.push(now);
  hits.set(key, arr);
  return true;
}

export function errorResponse(e: unknown): Response {
  if (e instanceof HttpError) return Response.json({ error: e.message }, { status: e.status });
  const code = (e as { code?: string }).code;
  if (code === "empty_message" || code === "message_too_long") return Response.json({ error: code }, { status: 400 });
  if (code === "conversation_not_found") return Response.json({ error: code }, { status: 404 });
  if (code === "turn_limit_reached") return Response.json({ error: code }, { status: 429 });
  console.error(JSON.stringify({ level: "error", event: "api_error", message: (e as Error).message }));
  return Response.json({ error: "internal_error" }, { status: 500 });
}
