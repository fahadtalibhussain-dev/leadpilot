import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        border: "hsl(220 13% 91%)",
        muted: "hsl(220 14% 96%)",
        "muted-foreground": "hsl(220 9% 46%)",
        primary: "hsl(238 75% 58%)",
        "primary-foreground": "hsl(0 0% 100%)",
      },
    },
  },
  plugins: [],
};

export default config;
