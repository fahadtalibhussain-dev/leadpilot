import { writeFileSync } from "fs";
import { chaosProvider, runEval } from "../src/shared/eval/harness";
import { DEFAULT_SUITE_ID, TESTCASES } from "../src/shared/eval/testcases";
import { createProvider } from "../src/shared/llm";

process.env.LEADPILOT_SILENT = process.env.LEADPILOT_SILENT ?? "1";

async function main() {
  const chaos = process.argv.includes("--chaos");
  const verbose = process.argv.includes("--verbose");
  const base = createProvider();
  const llm = chaos ? chaosProvider(base) : base;
  const report = await runEval({ suite: TESTCASES, suiteId: DEFAULT_SUITE_ID, llm });

  console.log(`\nLeadPilot eval — provider: ${report.llm}\n`);
  for (const r of report.results) {
    const ex = `${r.extractionCorrect}/${r.extractionExpected}`;
    console.log(`${r.passed ? "PASS" : "FAIL"}  ${r.id.padEnd(28)} extraction ${ex.padEnd(5)} stage ${r.stage.padEnd(13)} booked ${r.booked ? "yes" : "no "}`);
    if (!r.passed) for (const f of r.failures) console.log(`        - ${f}`);
    if (verbose) r.replies.forEach((x, i) => console.log(`        [${i + 1}] ${x}`));
  }
  const m = report.metrics;
  console.log("\n──────────────── SCORE REPORT ────────────────");
  console.log(`cases passed          ${m.passed}/${m.cases}`);
  console.log(`extraction accuracy   ${(m.extractionAccuracy * 100).toFixed(1)}%`);
  console.log(`hallucination count   ${m.hallucinationCount}  (fields: ${m.hallucinatedFields}, ungrounded replies: ${m.ungroundedReplies})`);
  console.log(`booking rate          ${(m.bookingRate * 100).toFixed(1)}% of leads that should book  (${(m.bookingRateOverall * 100).toFixed(0)}% of all 20)`);
  console.log(`stage accuracy        ${(m.stageAccuracy * 100).toFixed(1)}%`);
  console.log(`red-team pass rate    ${(m.redTeamPassRate * 100).toFixed(1)}%`);
  console.log(`JSON auto-repairs     ${m.repairs}`);
  writeFileSync("eval-report.json", JSON.stringify(report, null, 2));
  console.log("\nFull report written to eval-report.json");
  process.exit(m.passed === m.cases ? 0 : 1);
}

main().catch((e) => {
  console.error(e);
  process.exit(2);
});
