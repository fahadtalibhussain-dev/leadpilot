/**
 * Usage:  FIREBASE_SERVICE_ACCOUNT_JSON='{...}' npx tsx scripts/set-admin-claim.ts you@spacenos.com
 * Grants the `admin` custom claim (needed for /admin, runEvalSuite and generateProposal).
 */
import { cert, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";

async function main() {
  const email = process.argv[2];
  if (!email || !process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    console.error("usage: FIREBASE_SERVICE_ACCOUNT_JSON=... tsx scripts/set-admin-claim.ts <email>");
    process.exit(1);
  }
  initializeApp({ credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)) });
  const user = await getAuth().getUserByEmail(email);
  await getAuth().setCustomUserClaims(user.uid, { admin: true });
  console.log(`admin claim set for ${email} — sign out and back in to refresh the token`);
}
main();
