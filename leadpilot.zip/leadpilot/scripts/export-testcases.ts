import { writeFileSync } from "fs";
import { TESTCASES } from "../src/shared/eval/testcases";

// Deliverable: the 20 scripted conversations with expected extractedFields, as plain JSON.
writeFileSync("evals/testcases.json", JSON.stringify(TESTCASES, null, 2));
console.log(`Wrote evals/testcases.json (${TESTCASES.length} cases)`);
